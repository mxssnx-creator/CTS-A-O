# Simulated trading session — 8 symbols, 12 h pre-historic + 12 h run (tactics default, signals on)

Offline replay from the supplied cached candle feed (no market-data requests; original provider not recorded; simulated orders only; no exchange execution proof). Timeframe lanes 1 / 5 / 15 / 30 min set (independent + combined; traded: 1m), strategies Normal, Trailing, Axis, DCA with Block, signals. Configured Signal gate history 12 h; available evaluated prehistory 12 h, short by 0 h; indicator-only warm-up 0 h. The 12 h general engine prehistory is a separate boundary. Balance $10.00; each order volume unit = 0.1 % of the realized account balance at entry ($0.01–$0.01 before volume factors) at 10×; 0.15 % round-trip cost on every close. Window 2026-10-09T00:00 → 2026-10-09T12:00 UTC. Engine Base 151/27242 pairs passed; Signals 0/42 representative pairs pass the diagnostic gate (excluded from Base totals) — per range, passed / evaluated pairs · applied Base PF floor and passed-pair PF scores: Wide min PF 1.25 · 13/18268 · median gate PF score 2.06 · Micro min PF 1.05 · 0/4692 · Minimal min PF 1.08 · 27/24012 · median gate PF score 2.55 · Short min PF 1.12 · 0/0 (judged at the default cell — Wide's figures) · General min PF 1.25 · 0/0 (judged at the default cell — Wide's figures) · Long min PF 1.50 · 0/0 (judged at the default cell — Wide's figures) · Signals min PF 1.50 · 0/42; Main 30 pairs, 1102 tapes. First simulated step at 2026-10-09T00:00:00.000Z: 54 engine configs selected (Signal activation is separate). Paper selection after compute as of 2026-10-09T12:00:00.000Z: 31 engine configs + 3 Signal configs (complete paper step). Compute 20 s. The combined account PF includes both Base-qualified engine orders and separately activated Signal orders; the Base-to-execution benchmark is engine-only, and Signal PF is separate. Pre-validation candidate-pool PF is diagnostic. Causal: Base / Main / Real ranked on the history before the run.

**Simulated result (live sizing replay, position cap 0× balance per symbol × side, gross cap 0× balance (balance-volume defaults (no balance caps in the settings))):** balance $10.00 → $10.25 (2.54 %, closed orders) · equity at end $10.24 (open at end: 8 virtual positions / 79 virtual orders (79 funded), MTM -$0.02 (exact: executed by the engine through every gate, cap and Block volume, marked to market)) · Return PF 3.90 · cash PF (base $1) 3.90 · sized $ PF diagnostic 3.57 · 16 funded positions / 2195 orders opened (8 positions / 2116 orders settled; 8 positions / 79 orders still open) · 2116 virtual closes (0 zero allocations) · WR 88.61 % · DDT (closed trades, $) 4.42 h · DDR 0.22 · equity max drawdown $0.19 (1.87 %) · margin used max $1.44 · funded open avg 7.54 pos / 185.77 orders (peak 8 / 271)

Qualification uses the recorded full indication's runtime gates; Tactic minimum return PF 1.1, Short minimum return PF 1.1, preserving stricter settings. No-loss qualification uses the runtime score 4.
Direct walk-forward unit returns exclude the recorded combined external execution multiplier, including any Block, Relate, coordination, range and strategy factors; ladder/tape leg semantics remain. Cash, equity and sizing retain the stored weighted results.


### Signal historic Trailing qualification

Configured Signal gate history 12 h; available evaluated prehistory 12 h, short by 0 h; indicator-only warm-up 0 h. The 12 h general engine prehistory is a separate boundary. Missing history is not a pass. Generated candidates use completed entries inside that available Signal history (configured MFE minimum 30) and are re-simulated with the lane protect, signal filter, cooldown and modeled costs. A candidate qualifies only with at least 30 closed trades, PF ≥ 1.5 and DDR ≤ 1.

| pairs | pairs with insufficient entries | trails below minimum | candidates | PF-tested | insufficient closes | PF/net rejected | DDR rejected | qualified |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 42 | 42 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
**Caps:** position cap 0× balance per symbol × side, gross cap 0× balance (balance-volume defaults (no balance caps in the settings)) — 0 orders capped to $0, 0 scaled down (open at end: 0 capped, 0 scaled) · binding: position cap 0, gross cap 0. **Without the caps:** balance $10.00 → $10.25 (2.54 %) · Return PF 3.90 · cash PF (base $1) 3.90 · sized $ PF diagnostic 3.57 · equity at end $10.24 · equity max drawdown $0.19 (1.87 %) · margin used max $1.44.
**Virtual diagnostic:** 2116 closes · Return PF 3.90 before funding allocation; 0 zero allocations and 0 unknown allocations. Position episodes and explicitly virtual counts describe the native virtual book. Funded opening/settlement totals and headline occupancy use verified allocations; PF uses funded settled orders.

### Base gate: what each change would admit

From the same Base results — no recompute. The PF floor here changes the untagged / Wide fallback only; configured Micro, Minimal, Short, General and Long floors stay in force. "Pairs in a range" is what the tape stage builds from.

The median is the runtime's Base gate PF score. A no-loss pair uses the finite score 4; that is a qualification score, not an exact PF.

| Base gate | wide / fallback PF floor | closes | DDR | pairs at the default cell | pairs in a range | share | median PF score of the passed |
|---|---:|---:|---:|---:|---:|---:|---:|
| as run | 1.25 | 10 | 1 | 17 | 30  | 0.1 % | 2.062 |
| PF ≥ 1.00 | 1.00 | 10 | 1 | 17 | 30 (+0) | 0.1 % | 2.062 |
| PF ≥ 1.05 | 1.05 | 10 | 1 | 17 | 30 (+0) | 0.1 % | 2.062 |
| PF ≥ 1.20 | 1.20 | 10 | 1 | 17 | 30 (+0) | 0.1 % | 2.062 |
| closes ≥ 6 | 1.25 | 6 | 1 | 24 | 38 (+8) | 0.2 % | 2.062 |
| closes ≥ 20 | 1.25 | 20 | 1 | 0 | 1 (-29) | 0.0 % | – |
| closes ≥ 30 | 1.25 | 30 | 1 | 0 | 0 (-30) | 0.0 % | – |
| DDR off | 1.25 | 10 | off | 46 | 78 (+48) | 0.3 % | 1.547 |
| DDR ≤ 2 | 1.25 | 10 | 2 | 34 | 48 (+18) | 0.2 % | 1.719 |
| DDR ≤ 0.5 | 1.25 | 10 | 0.5 | 6 | 13 (-17) | 0.1 % | 4.000 |
| PF ≥ 1.00 · DDR off | 1.00 | 10 | off | 81 | 83 (+53) | 0.3 % | 1.289 |
| PF ≥ 1.00 · DDR off · closes ≥ 6 | 1.00 | 6 | off | 113 | 105 (+75) | 0.4 % | 1.375 |


### Base by range: which gate removes each pair

Each pair at the range's own cell against the range's minimum. "first" = the first gate missed (closes → net → PF → DDR); "only" = pairs that miss that one gate alone (removing it admits them).

| range | min PF | evaluated | passed | share | first: closes / net / PF / DDR | only: closes / net / PF / DDR | median PF, only DDR |
|---|---:|---:|---:|---:|---|---|---:|
| Wide | 1.25 | 18268 | 13 | 0.1 % | 17883 / 325 / 26 / 21 | 5 / 0 / 0 / 21 | 1.375 |
| Micro | 1.05 | 4692 | 0 | 0.0 % | 4692 / 0 / 0 / 0 | 0 / 0 / 0 / 0 | – |
| Minimal | 1.08 | 24012 | 27 | 0.1 % | 23395 / 534 / 5 / 51 | 6 / 0 / 0 / 51 | 1.238 |


### After each evaluation: PF and sets validated

Base: the Base-passed pairs pooled on their gross return basis; no-loss samples show ∞ (no loss), while the runtime's finite no-loss gate score is shown separately in the run summary. Validation: the sets validated at the run start and their gross-return PF pooled on the validation window (signals: units active in the run). Orders: the run's funded settled orders and their realized PF; known zero allocations are excluded.
Validation percentages use the displayed Base-qualified config inventory, including disabled types; the separate evaluated count excludes those types. Zero or missing denominators are unavailable, not 0%. Signals require their exact-context audit; active units are not a validation percentage.
With Axis perRange off, Wide-labeled validation and orders also include independent untagged DCA/Axis configs from pairs that qualified in another range, following the recorded builder admission policy.

| range | Base pooled PF | pairs validated (%) | effective validation min PF | post-Base validation PF | sets validated (%) | settled execution PF | orders |
|---|---:|---:|---|---:|---:|---:|---:|
| Wide | 2.31 | 13 of 18268 (0.07%) | 1.25 | ∞ (no loss) | 31 of 480 (6.46%) | 3.91 | 1259 |
| Micro | – | 0 of 4692 (0.00%) | not recorded | – | – | – | 0 |
| Minimal | 2.92 | 27 of 24012 (0.11%) | 1.08 | 14.09 | 23 of 118 (19.49%) | 3.87 | 857 |
| Short | – | 0 of 0 (percentage unavailable) | not recorded | – | – | – | 0 |
| General | – | 0 of 0 (percentage unavailable) | not recorded | – | – | – | 0 |
| Long | – | 0 of 0 (percentage unavailable) | not recorded | – | – | – | 0 |
| Signals | – | 0 of 42 (0.00%) | – | unavailable (use exact-context audit) | 3 units active; validation percentage unavailable | – | 0 |


### Each range at every step

Per range over the run's 12 steps: its tapes, the steps with configs validated (signals: active units) and with orders taken, and the totals.

| range | tapes | steps processed | steps with validated configs | steps with orders | validated (config × step) | candidates | orders |
|---|---:|---:|---:|---:|---:|---:|---:|
| Minimal | 118 | 12 / 12 | 12 | 11 | 221 | 1788 | 885 |
| Wide | 480 | 12 / 12 | 12 | 11 | 298 | 2279 | 1310 |
| Signals | 504 | 12 / 12 | 0 | 0 | 0 | 0 | 0 |

## Hour by hour

| hour (UTC) | virtual positions / owned orders closed | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | WR | net | balance | equity (end) | equity low | equity max DD % (so far) | DD time now (h, equity) | margin max | virtual open pos / orders |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 00:00 | 0 / 102 | 90 / 12 | 50.38 | 20.22 | 88 % | $0.01 | $10.01 | $10.00 | $9.99 | 0.18 % | 0.05 | $0.64 | 7 / 224 |
| 01:00 | 0 / 377 | 356 / 21 | 172.56 | 62.50 | 94 % | $0.06 | $10.07 | $10.07 | $10.00 | 0.18 % | 0.08 | $0.82 | 7 / 197 |
| 02:00 | 0 / 274 | 262 / 12 | 363.10 | 119.79 | 96 % | $0.04 | $10.11 | $10.10 | $10.02 | 0.67 % | 0.10 | $1.10 | 8 / 163 |
| 03:00 | 0 / 214 | 182 / 32 | 44.27 | 15.51 | 85 % | $0.03 | $10.14 | $10.14 | $10.09 | 0.67 % | 0.63 | $1.02 | 8 / 185 |
| 04:00 | 1 / 207 | 173 / 34 | 17.19 | 7.85 | 84 % | $0.03 | $10.17 | $10.14 | $10.13 | 0.67 % | 0.40 | $0.79 | 8 / 121 |
| 05:00 | 2 / 255 | 246 / 9 | 144.18 | 58.99 | 96 % | $0.05 | $10.21 | $10.20 | $10.15 | 0.67 % | 0.22 | $0.96 | 7 / 159 |
| 06:00 | 0 / 138 | 121 / 17 | 7.84 | 3.88 | 88 % | $0.02 | $10.23 | $10.22 | $10.21 | 0.67 % | 0.55 | $0.97 | 7 / 179 |
| 07:00 | 4 / 278 | 234 / 44 | 3.38 | 2.91 | 84 % | $0.03 | $10.27 | $10.28 | $10.20 | 0.78 % | 0.43 | $1.44 | 8 / 235 |
| 08:00 | 0 / 88 | 55 / 33 | 0.19 | 0.29 | 63 % | -$0.03 | $10.24 | $10.25 | $10.20 | 1.30 % | 1.43 | $1.25 | 8 / 201 |
| 09:00 | 0 / 9 | 6 / 3 | 0.62 | 0.45 | 67 % | -$0.00 | $10.24 | $10.22 | $10.21 | 1.30 % | 2.43 | $1.03 | 8 / 192 |
| 10:00 | 0 / 23 | 6 / 17 | 0.08 | 0.07 | 26 % | -$0.02 | $10.22 | $10.17 | $10.15 | 1.87 % | 3.43 | $0.98 | 8 / 189 |
| 11:00 | 1 / 151 | 144 / 7 | 423.11 | 122.43 | 95 % | $0.03 | $10.25 | $10.24 | $10.15 | 1.87 % | 4.43 | $0.91 | 8 / 79 |

**Last hour (11:00):** open at end: 8 virtual positions / 79 virtual orders (79 funded), MTM -$0.02 (exact: executed by the engine through every gate, cap and Block volume, marked to market); equity at the end $10.24 = balance $10.25 + MTM -$0.02.

**Hours positive:** 9 of 12 full hours · flat 0 · negative 3

*DD time now* = time since the equity (open positions marked to market) last stood at its peak, at the end of the hour; *DDT (closed trades)* in the result line is the drawdown time of the closed-trade curve. *Return PF* and *cash PF (base $1)* use the same canonical unit returns and should match; *sized $ PF diagnostic* = gross realized cash gains ÷ losses on those same orders after actual sizing; ∞ (no loss) = no losing order.

## Hour by hour per timeframe lane (orders · Return PF · net $)

| hour (UTC) | 1m |
|---|---:|
| 00:00 | 102 · 50.38 · $0.01 |
| 01:00 | 377 · 172.56 · $0.06 |
| 02:00 | 274 · 363.10 · $0.04 |
| 03:00 | 214 · 44.27 · $0.03 |
| 04:00 | 207 · 17.19 · $0.03 |
| 05:00 | 255 · 144.18 · $0.05 |
| 06:00 | 138 · 7.84 · $0.02 |
| 07:00 | 278 · 3.38 · $0.03 |
| 08:00 | 88 · 0.19 · -$0.03 |
| 09:00 | 9 · 0.62 · -$0.00 |
| 10:00 | 23 · 0.08 · -$0.02 |
| 11:00 | 151 · 423.11 · $0.03 |

## Hour by hour per type (funded orders · Return PF · WR · net $)

The strategy columns partition funded orders; virtual closes also include zero-allocated closes. *Of which* columns are subsets of the funded orders.

| hour (UTC) | funded orders closed | virtual closes | Normal | Trailing | Trailing only | DCA | Signal · Normal | Signal · Trailing | Signal · Trailing only | of which Block-raised | of which Signals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 00:00 | 102 | 102 | 8 · ∞ (no loss) · 100 % · $0.00 | 28 · 13.96 · 71 % · $0.00 | 6 · 0.19 · 33 % · -$0.00 | 60 · ∞ (no loss) · 100 % · $0.00 | – | – | – | 54 · 44.44 · 89 % · $0.01 | – |
| 01:00 | 377 | 377 | 32 · ∞ (no loss) · 100 % · $0.01 | 94 · 48.05 · 84 % · $0.03 | 16 · 14.12 · 63 % · $0.00 | 235 · ∞ (no loss) · 100 % · $0.02 | – | – | – | 302 · 118.89 · 94 % · $0.05 | – |
| 02:00 | 274 | 274 | 16 · ∞ (no loss) · 100 % · $0.01 | 78 · 75.55 · 87 % · $0.02 | 18 · 58.27 · 89 % · $0.00 | 162 · ∞ (no loss) · 100 % · $0.02 | – | – | – | 252 · 336.34 · 95 % · $0.04 | – |
| 03:00 | 214 | 214 | 12 · ∞ (no loss) · 100 % · $0.01 | 58 · 5.30 · 59 % · $0.01 | 24 · 15.48 · 67 % · $0.01 | 120 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 206 · 43.55 · 84 % · $0.03 | – |
| 04:00 | 207 | 207 | 23 · 10.59 · 96 % · $0.01 | 58 · 4.04 · 53 % · $0.01 | 12 · 11.88 · 50 % · $0.00 | 114 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 201 · 16.43 · 83 % · $0.03 | – |
| 05:00 | 255 | 255 | 24 · ∞ (no loss) · 100 % · $0.01 | 52 · 29.40 · 87 % · $0.02 | 10 · 18.82 · 80 % · $0.00 | 169 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 254 · 143.34 · 96 % · $0.05 | – |
| 06:00 | 138 | 138 | 11 · 4.81 · 91 % · $0.00 | 37 · 3.18 · 68 % · $0.01 | 10 · 2.21 · 60 % · $0.00 | 80 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 138 · 7.84 · 88 % · $0.02 | – |
| 07:00 | 278 | 278 | 27 · 2.27 · 85 % · $0.01 | 78 · 3.06 · 64 % · $0.01 | 15 · 2.22 · 47 % · $0.00 | 158 · 3.74 · 97 % · $0.01 | – | – | – | 278 · 3.38 · 84 % · $0.03 | – |
| 08:00 | 88 | 88 | 11 · 0.81 · 73 % · -$0.00 | 20 · 0.36 · 65 % · -$0.01 | 8 · 0.19 · 63 % · -$0.00 | 49 · 0.16 · 59 % · -$0.02 | – | – | – | 88 · 0.19 · 63 % · -$0.03 | – |
| 09:00 | 9 | 9 | 1 · 0.00 · 0 % · -$0.00 | – | – | 8 · 0.67 · 75 % · -$0.00 | – | – | – | 9 · 0.62 · 67 % · -$0.00 | – |
| 10:00 | 23 | 23 | 8 · 0.00 · 0 % · -$0.01 | 9 · 0.05 · 22 % · -$0.01 | 6 · 0.43 · 67 % · -$0.00 | – | – | – | – | 23 · 0.08 · 26 % · -$0.02 | – |
| 11:00 | 151 | 151 | 16 · ∞ (no loss) · 100 % · $0.01 | 30 · 31.77 · 77 % · $0.01 | 1 · ∞ (no loss) · 100 % · $0.00 | 104 · ∞ (no loss) · 100 % · $0.02 | – | – | – | 151 · 423.11 · 95 % · $0.03 | – |

## Post-Base paper Live gate

The paper entry stage independently checks each selected config's own last 25 settled post-Base execution closes since 2026-10-09T00:00:00.000Z against the stricter of its range PF floor and the Live PF floor. At the final paper step, 0 config windows had enough closes to be judged: 0 passed and 0 were paused; 0 new entry candidates were rejected by this gate. Exchange closes used: 0. Group last-N: 0.

The hourly order and PF tables above describe the causal walk-forward simulation. They are not rewritten by this later paper-stage gate; this section reports the gate's separate progress and skips.

## Stage funnel, hour by hour (post-gate virtual closes · one-unit PF)

Base (each pair at its default protect and its ranges' cells): 27200 engine pairs evaluated, 149 passed (any range); Signal pairs are measured separately. Later stages: *candidate pool* = every config of the Base-passed pairs (1102 tapes; diagnostic, before config validation), Normal / Trailing / Trailing only apart; *post-Base config passes* = 54 distinct configs passed at least one causal config-evaluation step across the window (a config can pass again in a later hour; the hourly row below counts those repeat pass instances). At run start, use the separate config-evaluation denominator/pass count and first simulated-step selection when recorded; the later paper/current selection is a separate snapshot; *post-gate virtual closes* = simulated trades that passed the causal config, coordination, caps and Block gates, before account funding/allocation. This count can include zero-allocated trades; funded settled orders and their PF are reported separately above. One-unit PF is every virtual close normalized to one unit after the 0.15 % cost. Config-evaluation history is 12 h (max of longH and preH); Base history is reported separately. Replay-only selection-window override: 12 h; it does not change normal runtime settings. The additional per-config entry last-N check is off (wf.lastN = 0); configEval still validates configs before seating. Separate post-Base paper Live-entry replay: last 25 closes per config, from 2026-10-09T00:00:00.000Z; see the Live gate section for judged and rejected counts.

| hour (UTC) | candidate pool (pre-validation) | pool Normal | pool Trailing | pool Trailing only | post-Base config-pass instances (hourly; may repeat) | post-gate virtual closes (pre-funding) | virtual Normal | virtual Trailing | virtual Trailing only | virtual Block-raised | virtual Signals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 00:00 | 636 · 1.16 | 74 · 2.04 | 179 · 1.07 | 83 · 0.37 | 129 · 6.31 | 102 · 50.38 | 8 · ∞ (no loss) | 28 · 13.96 | 6 · 0.19 | 54 · 44.44 | – |
| 01:00 | 2514 · 0.38 | 389 · 0.86 | 498 · 0.77 | 191 · 0.43 | 490 · 0.53 | 377 · 172.56 | 32 · ∞ (no loss) | 94 · 48.05 | 16 · 14.12 | 302 · 118.89 | – |
| 02:00 | 2812 · 0.69 | 356 · 0.87 | 581 · 0.92 | 302 · 1.01 | 491 · 0.86 | 274 · 363.10 | 16 · ∞ (no loss) | 78 · 75.55 | 18 · 58.27 | 252 · 336.34 | – |
| 03:00 | 1619 · 0.37 | 194 · 0.88 | 306 · 0.64 | 156 · 0.98 | 302 · 0.35 | 214 · 44.27 | 12 · ∞ (no loss) | 58 · 5.30 | 24 · 15.48 | 206 · 43.55 | – |
| 04:00 | 2201 · 0.39 | 377 · 0.76 | 483 · 0.55 | 189 · 0.45 | 407 · 0.32 | 207 · 17.19 | 23 · 10.59 | 58 · 4.04 | 12 · 11.88 | 201 · 16.43 | – |
| 05:00 | 1981 · 0.27 | 342 · 0.73 | 340 · 0.45 | 137 · 0.53 | 419 · 0.25 | 255 · 144.18 | 24 · ∞ (no loss) | 52 · 29.40 | 10 · 18.82 | 254 · 143.34 | – |
| 06:00 | 1438 · 0.64 | 283 · 0.99 | 331 · 0.78 | 123 · 0.40 | 311 · 0.56 | 138 · 7.84 | 11 · 4.81 | 37 · 3.18 | 10 · 2.21 | 138 · 7.84 | – |
| 07:00 | 2338 · 0.50 | 343 · 0.59 | 542 · 0.57 | 267 · 0.68 | 416 · 0.48 | 278 · 3.38 | 27 · 2.27 | 78 · 3.06 | 15 · 2.22 | 278 · 3.38 | – |
| 08:00 | 1948 · 0.53 | 273 · 0.80 | 393 · 0.46 | 223 · 0.26 | 402 · 0.57 | 88 · 0.19 | 11 · 0.81 | 20 · 0.36 | 8 · 0.19 | 88 · 0.19 | – |
| 09:00 | 925 · 1.42 | 127 · 0.72 | 167 · 0.41 | 79 · 0.36 | 177 · 2.95 | 9 · 0.62 | 1 · 0.00 | – | – | 9 · 0.62 | – |
| 10:00 | 1190 · 1.74 | 166 · 0.91 | 231 · 1.10 | 137 · 1.76 | 212 · 2.64 | 23 · 0.08 | 8 · 0.00 | 9 · 0.05 | 6 · 0.43 | 23 · 0.08 | – |
| 11:00 | 2713 · 1.22 | 411 · 0.79 | 530 · 0.59 | 210 · 0.50 | 501 · 1.44 | 151 · 423.11 | 16 · ∞ (no loss) | 30 · 31.77 | 1 · ∞ (no loss) | 151 · 423.11 | – |
| **total** | **22315 · 0.56** | **3335 · 0.81** | **4581 · 0.64** | **2097 · 0.59** | **4257 · 0.59** | **2116 · 3.90** | **189 · 3.98** | **542 · 4.28** | **126 · 2.65** | **1956 · 3.56** | **–** |

## Strategies

The type rows are one partition of the book (they add up to *total*); *of which* rows are subsets. DDT on each group's own $ curve, to the run end.

| strategy | orders | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | net | WR | DDT (h) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Normal | 189 | 171 / 18 | 3.98 | 3.98 | 3.48 | $0.06 | 90.48 % | 4.45 |
| Trailing | 542 | 390 / 152 | 4.28 | 4.28 | 3.95 | $0.10 | 71.96 % | 4.00 |
| Trailing only | 126 | 81 / 45 | 2.65 | 2.65 | 2.33 | $0.02 | 64.29 % | 4.70 |
| DCA | 1259 | 1233 / 26 | 3.91 | 3.91 | 3.78 | $0.08 | 97.93 % | 4.42 |
| Signal · Normal | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Signal · Trailing | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Signal · Trailing only | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| total | 2116 | 1875 / 241 | 3.90 | 3.90 | 3.57 | $0.25 | 88.61 % | 4.42 |
| of which Block-raised | 1956 | 1723 / 233 | 3.56 | 3.56 | 3.47 | $0.24 | 88.09 % | 4.42 |
| of which Signals | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| of which Engine (no signals) | 2116 | 1875 / 241 | 3.90 | 3.90 | 3.57 | $0.25 | 88.61 % | 4.42 |

## Timeframe lanes

| lane | orders | Return PF | cash PF (base $1) | sized $ PF diagnostic | net |
|---|---:|---:|---:|---:|---:|
| 1m | 2116 | 3.90 | 3.90 | 3.57 | $0.25 |

A 12 h window is a short sample: it shows the engine processing correctly and its current edge, not a durable result.

## Ranges in the executed book

Signals are a range of their own (signal configs carry no range tag); every enabled range listed.

| range | orders | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | net | WR | DDT (h) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Micro | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Minimal | 857 | 642 / 215 | 3.87 | 3.87 | 3.48 | $0.17 | 74.91 % | 4.45 |
| Short | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| General | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Long | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Wide | 1259 | 1233 / 26 | 3.91 | 3.91 | 3.78 | $0.08 | 97.93 % | 4.42 |
| Signals | 0 | 0 / 0 | – | – | – | $0.00 | – | – |

### Why candidates did not execute, per range

Every entry candidate of a seated config (and of an active signal) the run skipped, by the first gate it failed.

| range | skipped | reasons (count) |
|---|---:|---|
| Wide | 969 | directionValidation 772 · configValidation 160 · symPf 37 |
| Minimal | 903 | directionValidation 704 · configValidation 129 · symPf 70 |

## Base said, the book did — the same ranges on the same basis

The combined account result includes every funded engine and Signal order. For the Base-to-execution benchmark, engine range rows contain only funded orders from Base-qualified pairs whose configs passed post-Base validation; Signals are separately activated, qualified and reported. All PF gates use net returns. Base lists a median gate score across passed pairs on its Base sample; a no-loss Base sample has an exact pooled PF of ∞ and a separate finite gate score. The run PF is on the actual executed order cohort. These samples and reducers differ, so
their difference alone does not establish edge loss or a sizing effect. Cash PF is a separate diagnostic on
the same closed orders as the book's return PF; unequal notionals can change cash PF without changing return PF.

| range | Base passed (median gate score, validation sample) | simulated return PF (run closes) | cash PF (base $1) | sized $ PF diagnostic (same run closes) | orders |
|---|---:|---:|---:|---:|---:|
| Micro | – | – | – | – | 0 |
| Minimal | 2.55 | 3.87 | 3.87 | 3.48 | 857 |
| Short (Base at the default cell) | – | – | – | – | 0 |
| General (Base at the default cell) | – | – | – | – | 0 |
| Long (Base at the default cell) | – | – | – | – | 0 |
| Wide | 2.06 | 3.91 | 3.91 | 3.78 | 1259 |
| Signals | – | – | – | – | 0 |

## Seated configs over the run window, by range and type

Engine configs that passed the seat evaluation (configEval) at the run start (54 of 478 evaluated, 598 engine tapes) and the signal configs' entries made while their unit (pair × symbol × direction) was active at the entry's step (0 units active at the run start, 3 over the run, 0 of 504 signal configs with such an entry), each on its own closes inside the run (entries ≥ start, exits ≤ end). Net in % of one unit; PF unit basis.

| range | type | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | normal | 6 | 0 (0 %) | 408 | 68 % | 0.81 | -43.60 |
| Minimal | trailing | 13 | 0 (0 %) | 1199 | 57 % | 0.66 | -151.70 |
| Minimal | trailing-only | 4 | 0 (0 %) | 284 | 53 % | 0.61 | -44.85 |
| Wide | dca | 31 | 0 (0 %) | 2366 | 84 % | 0.56 | -1241.97 |

| range | indication kind | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | active | 3 | 0 (0 %) | 376 | 59 % | 0.68 | -44.77 |
| Minimal | break | 4 | 0 (0 %) | 373 | 62 % | 0.73 | -42.39 |
| Minimal | channel | 4 | 0 (0 %) | 232 | 62 % | 0.70 | -33.26 |
| Minimal | direction | 4 | 0 (0 %) | 351 | 61 % | 0.77 | -33.56 |
| Minimal | inverse | 3 | 0 (0 %) | 246 | 51 % | 0.71 | -23.68 |
| Minimal | micro | 4 | 0 (0 %) | 236 | 57 % | 0.52 | -55.46 |
| Minimal | osc | 1 | 0 (0 %) | 77 | 52 % | 0.72 | -7.04 |
| Wide | active | 10 | 0 (0 %) | 870 | 83 % | 0.58 | -446.69 |
| Wide | break | 4 | 0 (0 %) | 331 | 84 % | 0.56 | -167.38 |
| Wide | channel | 3 | 0 (0 %) | 163 | 80 % | 0.39 | -128.84 |
| Wide | direction | 4 | 0 (0 %) | 320 | 83 % | 0.53 | -199.76 |
| Wide | inverse | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 |
| Wide | micro | 4 | 0 (0 %) | 234 | 85 % | 0.43 | -148.01 |
| Wide | osc | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 |

### Seat evaluation (configEval) at the run start, per range (configs failing at each gate, first gate missed)

Each engine config on its own closes at the run start (configEval: the gates the seat selection applies — not the Base stage, which ranks bot × indication pairs): over the selection window (12 h) ≥ max(3, 10) closes, positive net, PF ≥ its full indication's range minimum (stage 1.25; general 1.25, long 1.5, micro 1.05, minimal 1.08, short 1.12; full indication-aware Tactic floor 1.1, Short floor 1.1, retaining stricter settings; mixed indication groups can have different minima), drawdown time ≤ min(5.83 h, 35 h × span ÷ 72 h), span = the tape's own history inside the 12 h window (ddtLimitH: a 1m tape with 72 h of history → 35 h; a full window → 5.83 h), drawdown ratio ≤ 1, last 10 closes at the same PF / DDT, range cells' last 75 at PF ≥ 1.35, positive lower-confidence bound, green hours ≥ 50 %. Real entries then check the last 0 closes again. Signal configs are not evaluated here: they are seated by their own signal activation. PF medians: the configEval window PF of every evaluated config / of the passed ones (unit basis; a config with no loss uses the runtime's no-loss gate score, not an exact finite ratio).

| range | configs | evaluated | passed | median PF score (evaluated) | median PF score (passed) | DDT limit h (min–max) | closes | net | pf | pre | lcb | lastN | rangeGate | context | ddt | ddr | green | stable | type off | pair not Base-passed | note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Micro | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no Micro indication in the focus |
| Minimal | 118 | 118 | 23 | 4.00 | 9.41 | 5.83–5.83 (median 5.83) | 88 | 5 | 0 | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Short | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| General | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| Long | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| Wide | 480 | 360 | 31 | 4.00 | 4.00 | 5.83–5.83 (median 5.83) | 329 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 120 | 0 |  |
| Signals | 504 | – | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 504 signal tapes, 0 units (pair × symbol × direction) active at the run start, 3 over the run; 0 configs entered while their unit was active — seated per unit and step, not configEval |

## Diagnostic: every config over the run window, by range and type (context: seated or not)

Each config computed independently (unit size, 0.15 % cost per close), on the book's rule (entries ≥ start, exits ≤ end); net in % of one unit summed over the closes. This all-candidate table is diagnostic only: it is not the PF benchmark and does not qualify or dilute the post-Base execution cohort.

| range | type | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | normal | 46 | 6 (13 %) | 3059 | 68 % | 0.81 | -317.65 |
| Minimal | trailing | 46 | 0 (0 %) | 4025 | 54 % | 0.63 | -555.28 |
| Minimal | trailing-only | 26 | 1 (4 %) | 1816 | 50 % | 0.60 | -296.68 |
| Wide | axis | 240 | 20 (8 %) | 1796 | 35 % | 0.29 | -1001.78 |
| Wide | dca | 120 | 1 (1 %) | 7732 | 82 % | 0.55 | -4463.11 |
| Wide | dca-active | 120 | 1 (1 %) | 2774 | 36 % | 0.45 | -628.80 |
| Signals | normal | 126 | 9 (7 %) | 276 | 55 % | 0.76 | -24.22 |
| Signals | trailing | 252 | 14 (6 %) | 556 | 50 % | 0.69 | -53.25 |
| Signals | trailing-only | 126 | 3 (2 %) | 281 | 45 % | 0.50 | -37.01 |

## Range cells by indication kind (seated configs; signal configs by source)

| range | kind | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | active | 3 | 0 (0 %) | 376 | 59 % | 0.68 | -44.77 |
| Minimal | break | 4 | 0 (0 %) | 373 | 62 % | 0.73 | -42.39 |
| Minimal | channel | 4 | 0 (0 %) | 232 | 62 % | 0.70 | -33.26 |
| Minimal | direction | 4 | 0 (0 %) | 351 | 61 % | 0.77 | -33.56 |
| Minimal | inverse | 3 | 0 (0 %) | 246 | 51 % | 0.71 | -23.68 |
| Minimal | micro | 4 | 0 (0 %) | 236 | 57 % | 0.52 | -55.46 |
| Minimal | osc | 1 | 0 (0 %) | 77 | 52 % | 0.72 | -7.04 |
| Wide | active | 10 | 0 (0 %) | 870 | 83 % | 0.58 | -446.69 |
| Wide | break | 4 | 0 (0 %) | 331 | 84 % | 0.56 | -167.38 |
| Wide | channel | 3 | 0 (0 %) | 163 | 80 % | 0.39 | -128.84 |
| Wide | direction | 4 | 0 (0 %) | 320 | 83 % | 0.53 | -199.76 |
| Wide | inverse | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 |
| Wide | micro | 4 | 0 (0 %) | 234 | 85 % | 0.43 | -148.01 |
| Wide | osc | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 |

## Causal last-50 gate on the seated configs: their last 50 closes before the run cleared the PF, then inside the run

| range | min PF | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|

## Indications per range (seated configs of the indication together; positive net first, then by net)

| range | bot | indication | configs | positive | closes | WR | PF unit | net % | best config (closes · PF unit · net %) |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| Minimal | revert | mc-rsi2-20@m1 | 1 | 0 (0 %) | 106 | 65 % | 0.83 | -6.33 | tp0.8 sl2.4 tr0.4 h960 mn (106 · 0.83 · -6.33) |
| Minimal | revert | cci-14-100@m1 | 1 | 0 (0 %) | 77 | 52 % | 0.72 | -7.04 | tp0.8 sl2.4 tr0.4 h960 mn (77 · 0.72 · -7.04) |
| Minimal | follow | inverse-known-cci-14-100@m1 | 3 | 0 (0 %) | 246 | 51 % | 0.71 | -23.68 | tp0 sl2.4 tr0.4 h960 mn to tm3 (76 · 0.77 · -5.68) |
| Minimal | revert | r-linreg@m1 | 4 | 0 (0 %) | 232 | 62 % | 0.70 | -33.26 | tp0.8 sl2.4 tr0 h960 mn (44 · 0.99 · -0.20) |
| Minimal | follow | dir-thrust@m1 | 4 | 0 (0 %) | 351 | 61 % | 0.77 | -33.56 | tp0.8 sl2.4 tr0 h960 mn (64 · 0.91 · -3.20) |
| Minimal | revert | mc-rsi2-25@m1 | 2 | 0 (0 %) | 270 | 57 % | 0.62 | -38.44 | tp0.8 sl2.4 tr0.4 h960 mn (112 · 0.74 · -10.38) |
| Minimal | follow | r-nr-break-m@m1 | 4 | 0 (0 %) | 373 | 62 % | 0.73 | -42.39 | tp0.8 sl2.4 tr0.4 h960 mn (99 · 0.85 · -4.57) |
| Minimal | follow | micro-1x5-drawdown-market-fast@m1 | 4 | 0 (0 %) | 236 | 57 % | 0.52 | -55.46 | tp0.8 sl1.2 tr0.4 h960 mn (66 · 0.58 · -12.39) |
| Wide | follow | micro-1-flow-break-selective@m1 | 2 | 0 (0 %) | 75 | 92 % | 0.74 | -12.93 | tp0.55 sl0.59 tr0 h480 dc2s1q0g0.5r2.5m2 dca (37 · 0.78 · -5.42) |
| Wide | follow | inverse-known-cci-14-100@m1 | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 | tp0.81 sl0.84 tr0 h480 dc2s1q0g0.5r2.5m2 dca (61 · 0.84 · -11.23) |
| Wide | revert | cci-14-100@m1 | 3 | 0 (0 %) | 224 | 86 % | 0.66 | -75.65 | tp0.81 sl0.84 tr0 h480 dc2s1q0g0.5r2.5m2 dca (61 · 0.84 · -11.23) |
| Wide | revert | mc-trsi2-10@m1 | 2 | 0 (0 %) | 100 | 78 % | 0.25 | -118.76 | tp0.55 sl0.59 tr0 h480 dc2s1q0g0.5r2.5m2 dca (49 · 0.27 · -58.40) |
| Wide | revert | r-linreg@m1 | 3 | 0 (0 %) | 163 | 80 % | 0.39 | -128.84 | tp0.81 sl0.84 tr0 h480 dc2s1q0g0.5r2.5m2 dca (49 · 0.50 · -35.60) |
| Wide | follow | micro-1x5-market-follow-selective@m1 | 2 | 0 (0 %) | 159 | 82 % | 0.35 | -135.08 | tp0.55 sl0.59 tr0 h480 dc2s1q0g0.5r2.5m2 dca (78 · 0.37 · -65.65) |
| Wide | revert | mc-rsi2-20@m1 | 4 | 0 (0 %) | 384 | 84 % | 0.66 | -154.85 | tp1.01 sl1.03 tr0 h480 dc2s1q0g0.5r2.5m2 dca (69 · 0.77 · -25.54) |
| Wide | follow | r-nr-break-m@m1 | 4 | 0 (0 %) | 331 | 84 % | 0.56 | -167.38 | tp0.81 sl0.84 tr0 h480 dc2s1q0g0.5r2.5m2 dca (69 · 0.61 · -37.29) |
| Wide | revert | mc-rsi2-25@m1 | 4 | 0 (0 %) | 386 | 83 % | 0.63 | -173.08 | tp1.01 sl1.03 tr0 h480 dc2s1q0g0.5r2.5m2 dca (67 · 0.70 · -36.07) |
| Wide | follow | dir-thrust@m1 | 4 | 0 (0 %) | 320 | 83 % | 0.53 | -199.76 | tp1.01 sl1.03 tr0 h480 dc2s1q0g0.5r2.5m2 dca (61 · 0.72 · -28.35) |

## Best range cells by net (seated configs, ≥ 10 closes, all pairs together)

| range | TP | SL | trail | configs | positive | closes | WR | PF unit | net % |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | tp 0.800% | sl 3.00× | tr off | 3 | 0 (0 %) | 170 | 77 % | 0.86 | -14.30 |
| Minimal | tp 0.800% | sl 1.50× | tr off | 3 | 0 (0 %) | 238 | 61 % | 0.76 | -29.30 |
| Minimal | tp 0.000% | sl Infinity× | tr Infinity× | 4 | 0 (0 %) | 284 | 53 % | 0.61 | -44.85 |
| Minimal | tp 0.800% | sl 3.00× | tr 0.50× | 8 | 0 (0 %) | 670 | 60 % | 0.71 | -71.73 |
| Minimal | tp 0.800% | sl 1.50× | tr 0.50× | 5 | 0 (0 %) | 529 | 53 % | 0.59 | -79.97 |
| Wide | tp 1.010% | sl 1.02× | tr off | 4 | 0 (0 %) | 252 | 77 % | 0.70 | -127.75 |
| Wide | tp 0.810% | sl 1.04× | tr off | 7 | 0 (0 %) | 482 | 81 % | 0.69 | -201.95 |
| Wide | tp 0.550% | sl 1.07× | tr off | 10 | 0 (0 %) | 781 | 85 % | 0.48 | -451.66 |
| Wide | tp 0.500% | sl 1.08× | tr off | 10 | 0 (0 %) | 851 | 86 % | 0.46 | -460.62 |

## Worst range cells by net (seated configs, the rows not in the best table)

| range | TP | SL | trail | configs | positive | closes | WR | PF unit | net % |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| – | | | | | | | | | |

## Config sets: completeness (the Base gate decides which pairs and targets build)

Every indication × range × strategy type: the grid's cells (target × stop × trail × hold), built (simulated), kept before the pre-run range gate, rejected by that gate, eligible after it, dropped for too few closes (the range gate's last N can never be met), and not built by reason (baseRange: the pair did not pass Base in that range; baseTarget: the target did not pass Base; duplicate: two grid cells map onto one config on a slow lane).

| range | type | indications (with sets) | grid cells | built | kept before gate | gate rejected | eligible | too few closes | not built |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| Minimal | normal | 27 (23) | 60 | 46 | 46 | 0 | 46 | 0 | baseTarget 8 · baseRange 6 |
| Minimal | trailing | 27 (23) | 60 | 46 | 46 | 0 | 46 | 0 | baseTarget 8 · baseRange 6 |
| Minimal | trailing-only | 27 (10) | 60 | 26 | 26 | 0 | 26 | 0 | baseTarget 28 · baseRange 6 |
| Wide | axis | 27 (27) | 240 | 240 | 240 | 0 | 240 | 0 | – |
| Wide | dca | 27 (27) | 120 | 120 | 120 | 0 | 120 | 0 | – |
| Wide | dca-active | 27 (27) | 120 | 120 | 120 | 0 | 120 | 0 | – |

Engine indications Base evaluated that built no set: 1515 (act-burst, act-burst-1.5, act-burst-2.5, act-burst-2.5@x4, act-chop, act-chop@x4, act-hf, act-hf-8, act-shift, aroon-14, aroon-25, bb-bounce, bb-bounce-20-2.5, bb-bounce-20-3, bb-bounce-50-2, bb-mid, bb-walk, bb-walk-50, bb-walk@x4, bb-wick, break-atr, break-atr-0.9, break-atr-1.5, break-atr-2, break-atr-2@x4, break-don10, break-don20, break-don40, break-don55, break-fail, break-mc-rel-don-5-dd24-balanced, break-mc-rel-don-5-dd24-guarded, break-mc-rel-don-5-dd48-balanced, break-mc-rel-don-5-dd48-guarded, break-mc-rel-don-5x15-dd24-balanced, break-mc-rel-don-5x15-dd24-guarded, break-mc-rel-don-5x15-dd48-balanced, break-mc-rel-don-5x15-dd48-guarded, break-mc-rel-don8-5-dd24-balanced, break-mc-rel-don8-5-dd24-guarded, …).

## Heatmaps: target × stop per range (PF unit, closes; every type and trail together)

### Minimal — every config computed

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 0.67 (4076) |
| 3× | 0.80 (3008) |

### Minimal — configs that passed their evaluation

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 0.66 (767) |
| 3× | 0.75 (840) |

### Minimal — orders executed

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 2.86 (280) |
| 3× | 5.85 (451) |

### Wide — every config computed

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.81 % | tp 1.01 % |
|---|---:|---:|---:|---:|
| 1.02× | – | – | – | 0.62 (2148) |
| 1.04× | – | – | 0.59 (2401) | – |
| 1.07× | – | 0.47 (2892) | – | – |
| 1.08× | 0.40 (4861) | – | – | – |

### Wide — configs that passed their evaluation

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.81 % | tp 1.01 % |
|---|---:|---:|---:|---:|
| 1.02× | – | – | – | 0.70 (252) |
| 1.04× | – | – | 0.69 (482) | – |
| 1.07× | – | 0.48 (781) | – | – |
| 1.08× | 0.46 (851) | – | – | – |

### Wide — orders executed

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.81 % | tp 1.01 % |
|---|---:|---:|---:|---:|
| 1.02× | – | – | – | 4.51 (142) |
| 1.04× | – | – | 4.13 (260) | – |
| 1.07× | – | 3.77 (413) | – | – |
| 1.08× | 3.41 (444) | – | – | – |
