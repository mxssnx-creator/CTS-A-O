// Range checks for a settings patch, shared by the Settings page, the preset dialog and presets (pure: testable).
import { GRID_VARIANTS_MAX, MAX_EXCHANGE_POSITIONS, MAX_FOCUS_PAIRS, type CoreSettings } from "./config.ts";
import { MAX_MODEL_RT_COST } from "./model-cost.ts";
import { INDICATION_KINDS } from "./domain/types.ts";
import { validPromotedLaneProof } from "./live-promote.ts";
import { validVolumeRatio } from "./volume-ratio.ts";

/** Range checks for a settings patch (Settings page and preset dialog alike). */
export function checkSettings(s: Partial<CoreSettings>) {
  const num = (v: unknown, lo: number, hi: number, name: string) => {
    if (v === undefined) return;
    if (typeof v !== "number" || !Number.isFinite(v) || v < lo || v > hi)
      throw new Error(`${name} out of range`);
  };
  const volumeFactor = (v: unknown, name: string) => {
    if (v !== undefined && !validVolumeRatio(v))
      throw new Error(`${name} must be 0.1–5 in 0.1 steps`);
  };
  volumeFactor(s.exitStrategy?.volumeFactor, "Exit volume factor");
  num(s.symbols, 1, 120, "symbols");
  if (
    s.symbolRank !== undefined &&
    !["volatility1h", "change1h5m", "volume", "market", "gainers", "losers"].includes(s.symbolRank)
  )
    throw new Error("unknown symbol ranking");
  num(s.historyDays, 2, 45, "historyDays");
  num(s.cycleMs, 100, 600_000, "cycle (ms)");
  num(s.tickMs, 50, 10_000, "tick (ms)");
  num(s.live?.syncMs, 250, 60_000, "exchange sync (ms)");
  num(s.symbolOffset, 0, 200, "symbol offset");
  if (s.forceSymbols !== undefined) {
    if (!Array.isArray(s.forceSymbols) || s.forceSymbols.length > 50)
      throw new Error("forced symbols: a list of at most 50");
    for (const x of s.forceSymbols)
      if (typeof x !== "string" || !/^[A-Za-z0-9]{1,20}(-?USDT)?$/i.test(x.trim()))
        throw new Error(`forced symbol ${String(x)}: like XRP or XRP-USDT`);
  }
  num(s.live?.minStopPct, 0.001, 0.2, "minimum stop");
  num(s.cost, 0, MAX_MODEL_RT_COST, "modeled round-trip cost (maximum 0.15%)");
  num(s.armTop, 1, 40, "armTop");
  num(s.mainTop, 0, 100_000, "mainTop");
  if (s.grid?.minSlEval !== undefined) num(s.grid.minSlEval, 0.0005, 0.05, "grid.minSlEval");
  if (s.grid?.baseTargets !== undefined && typeof s.grid.baseTargets !== "boolean")
    throw new Error("grid base targets: on / off");
  if (s.grid?.wideMinTf !== undefined)
    num(s.grid.wideMinTf, 0, 240, "grid.wideMinTf (Wide shortest lane, minutes)");
  volumeFactor(s.grid?.volumeFactor, "Wide volume factor");
  num(s.refineTop, 1, 100, "refineTop");
  num(s.evalTop, 1, 400, "evalTop");
  num(s.paperNotional, 1, 1_000_000, "paperNotional");
  num(s.paperBalance, 1, 100_000_000, "paper balance");
  if (s.sizing) {
    if (s.sizing.mode !== undefined && s.sizing.mode !== "equityPct")
      throw new Error("sizing: only account-balance percentage sizing is supported");
    num(s.sizing.pct, 0.001, 0.25, "sizing % of balance per order");
  }
  const int = (v: unknown, name: string) => {
    if (v !== undefined && !Number.isInteger(v)) throw new Error(`${name} must be a whole number`);
  };
  int(s.symbols, "symbols");
  int(s.refineTop, "refineTop");
  int(s.evalTop, "evalTop");
  int(s.mainTop, "mainTop");
  int(s.armTop, "armTop");
  int(s.axis?.levels, "axis levels");
  int(s.dca?.levels, "dca levels");
  int(s.live?.maxPositions, "max positions");
  // tfMin is the base data timeframe (1m); older presets carry their research timeframe and are normalised
  if (s.tfMin !== undefined && ![1, 5, 15, 30, 60].includes(s.tfMin))
    throw new Error("tfMin must be 1, 5, 15, 30 or 60");
  if (s.tfs !== undefined) {
    if (!Array.isArray(s.tfs) || !s.tfs.every((x) => [1, 5, 15, 30].includes(x)))
      throw new Error("timeframes: any of 1, 5, 15, 30 (minutes)");
    if (!s.tfs.includes(1)) throw new Error("timeframes: 1m is the base and always on");
  }
  if (s.tfDays !== undefined) {
    if (typeof s.tfDays !== "object" || s.tfDays === null)
      throw new Error("lane history: days per timeframe");
    for (const [k, v] of Object.entries(s.tfDays)) {
      if (!["1", "5", "15", "30"].includes(k))
        throw new Error(`lane history: unknown timeframe ${k}`);
      num(v, 1, 45, `lane history ${k}m`);
    }
  }
  if (s.gates) {
    // legacy values are snapped into 1.05–1.50 / 2–35 h by the runtime; only nonsense is rejected
    num(s.gates.minPf, 0.5, 5, "min PF");
    num(s.gates.maxDdtH, 1, 500, "max DDT");
    num(s.gates.minDdtH, 0, 72, "min DDT (floor under the scaled limit)");
    if (s.gates.maxDdr !== undefined) num(s.gates.maxDdr, 0, 20, "max drawdown ratio (DDR)");
    if (s.gates.lastNFloor !== undefined) {
      num(s.gates.lastNFloor, 0, 100, "last-N floor (closes)");
      int(s.gates.lastNFloor, "last-N floor");
    }
    if (s.gates.warmup !== undefined && typeof s.gates.warmup !== "boolean")
      throw new Error("sample warm-up (gates.warmup): true or false");
    if (s.gates.minGreen !== undefined)
      num(s.gates.minGreen, 0, 1, "minimum hourly success (green-hour share)");
    if (s.gates.rangeMinPf !== undefined) {
      if (typeof s.gates.rangeMinPf !== "object" || s.gates.rangeMinPf === null)
        throw new Error("range min PF: an object per range");
      const keys = new Set(["micro", "minimal", "short", "general", "long"]);
      for (const [k, v] of Object.entries(s.gates.rangeMinPf)) {
        if (!keys.has(k)) throw new Error(`range min PF: unknown range ${k}`);
        if (v !== undefined) num(v, 1.05, 3, `${k} min PF`);
      }
    }
    if (s.gates.stableBlocks !== undefined && s.gates.stableBlocks !== 0)
      num(s.gates.stableBlocks, 2, 12, "stability blocks");
    if (s.gates.baseSetsMinPf !== undefined) num(s.gates.baseSetsMinPf, 0.5, 1.5, "Base PF for computing a pair's sets");
    // null = off (as unset)
    if (s.gates.baseWindows !== undefined && s.gates.baseWindows !== null) {
      const bw = s.gates.baseWindows as unknown;
      if (typeof bw !== "object" || bw === null || Array.isArray(bw))
        throw new Error("two-window Base (gates.baseWindows): { gate?: rule, report?: [rule, …] }");
      for (const k of Object.keys(bw))
        if (k !== "gate" && k !== "report") throw new Error(`two-window Base: unknown key ${k} (gate, report)`);
      const { gate, report } = bw as { gate?: unknown; report?: unknown };
      if (gate !== undefined) checkBaseWindowRule(gate, "two-window Base gate");
      if (report !== undefined) {
        if (!Array.isArray(report) || report.length > 8)
          throw new Error("two-window Base report: a list of at most 8 rules");
        report.forEach((r, i) => checkBaseWindowRule(r, `two-window Base report rule ${i + 1}`));
      }
    }
    num(s.gates.minTrades, 1, 500, "minTrades");
    num(s.gates.quorum, 0, 1, "quorum");
  }
  if (s.protectFloor) {
    num(s.protectFloor.minSl, 0, 0.1, "minimum stop");
    num(s.protectFloor.minTrail, 0, 0.1, "minimum trailing distance");
  }
  if (s.live) {
    num(s.live.notionalUsd, 1, 500, "notionalUsd");
    num(s.live.maxPositions, 1, MAX_EXCHANGE_POSITIONS, "maxPositions");
    if (
      s.live.connId !== undefined &&
      !["bingx-x01", "bingx-vst-01", "bingx-vst-02"].includes(s.live.connId)
    )
      throw new Error("unknown connection");
    if (s.live.requireReady !== undefined && typeof s.live.requireReady !== "boolean")
      throw new Error("live requireReady must be true or false");
    if (s.live.enabled !== undefined && typeof s.live.enabled !== "boolean")
      throw new Error("live.enabled must be boolean");
    if (s.live.mode !== undefined && !["overall", "entries"].includes(s.live.mode))
      throw new Error("live mode must be overall or entries");
    num(s.live.ratio, 0.1, 500, "control ratio"); // the caps (per position, exposure, risk budget) bound the size
    if (s.live.liveLastN !== undefined) num(s.live.liveLastN, 0, 200, "live last N");
    if (s.live.liveMinPf !== undefined) num(s.live.liveMinPf, 0, 10, "live min PF");
    if (s.live.engineProofN !== undefined) {
      num(s.live.engineProofN, 0, 1000, "engine proof closes");
      int(s.live.engineProofN, "engine proof closes");
    }
    if (s.live.engineProofPf !== undefined) num(s.live.engineProofPf, 0, 10, "engine proof PF");
    if (s.live.signalProofN !== undefined) {
      num(s.live.signalProofN, 0, 1000, "signal proof closes");
      int(s.live.signalProofN, "signal proof closes");
    }
    if (s.live.signalProofPf !== undefined) num(s.live.signalProofPf, 0, 10, "signal proof PF");
    if (s.live.signalProofEvents !== undefined) {
      num(s.live.signalProofEvents, 1, 100, "signal proof events");
      int(s.live.signalProofEvents, "signal proof events");
    }
    if (
      s.live.promotedLanes !== undefined &&
      (!Array.isArray(s.live.promotedLanes) ||
        s.live.promotedLanes.some((lane) => !lane || !validPromotedLaneProof(lane, lane.asOf)))
    )
      throw new Error(
        "promoted lanes: exact, complete after-Base and owned-execution proofs required",
      );
    if (s.live.kinds !== undefined) {
      if (!Array.isArray(s.live.kinds)) throw new Error("live kinds: a list of strategy kinds");
      const ok = new Set([
        "normal",
        "trailing",
        "trailing-only",
        "exit",
        "dca",
        "dca-active",
        "axis",
      ]);
      for (const k of s.live.kinds)
        if (!ok.has(k))
          throw new Error(`live kinds: ${k} is not a strategy kind (${[...ok].join(", ")})`);
    }
    if (s.live.plainOnly !== undefined && typeof s.live.plainOnly !== "boolean")
      throw new Error("live plain only: on / off");
    if (s.live.source !== undefined && !["all", "signals", "engine"].includes(s.live.source))
      throw new Error("live source: all, signals or engine");
    if (s.live.excludeRanges !== undefined) {
      const ok = ["wide", "mc", "mn", "mp", "sh", "gn", "lg"];
      if (!Array.isArray(s.live.excludeRanges) || s.live.excludeRanges.some((r) => !ok.includes(r)))
        throw new Error(`live excluded ranges: a list of ${ok.join(", ")}`);
    }
    if (s.live.excludeConfigs !== undefined) {
      // a family: bot|range for Normal / Trailing, or bot|exit for all Historic Exit sets
      const re = /^[a-z]+\|(wide|mc|mn|mp|sh|gn|lg|exit)$/;
      if (
        !Array.isArray(s.live.excludeConfigs) ||
        s.live.excludeConfigs.some((f) => typeof f !== "string" || !re.test(f))
      )
        throw new Error(
          "live excluded configs: bot|range families or bot|exit, e.g. follow|mn, revert|wide or follow|exit",
        );
    }
    if (s.live.top !== undefined && s.live.top !== "fill")
      num(s.live.top, 0, 100_000, "top configs");
    if (s.live.signalWeight !== undefined) num(s.live.signalWeight, 0, 30, "signal volume weight");
    if (s.live.signalsByScore !== undefined && typeof s.live.signalsByScore !== "boolean")
      throw new Error("signalsByScore: true or false");
    if (s.live.liveGroupLastN !== undefined) num(s.live.liveGroupLastN, 0, 2000, "live group last N");
    if (s.live.sideGates !== undefined && typeof s.live.sideGates !== "boolean")
      throw new Error("live side gates: true or false");
    if (s.live.maxExposureX !== undefined) num(s.live.maxExposureX, 0, 500, "max exposure × balance");
    if (s.live.exposureScaler !== undefined && typeof s.live.exposureScaler !== "boolean")
      throw new Error("exposureScaler: true or false");
    if (s.live.maxRiskPct !== undefined) num(s.live.maxRiskPct, 0, 1, "stop-risk budget (fraction of balance)");
    if (s.live.maxChase !== undefined) num(s.live.maxChase, 0, 5, "maximum chase (fraction of a lane's target distance)");
    if (s.live.foreignSides !== undefined && s.live.foreignSides !== "avoid" && s.live.foreignSides !== "independent")
      throw new Error('foreign sides: "avoid" or "independent"');
    if (
      s.live.positionSize !== undefined &&
      s.live.positionSize !== "lanes" &&
      s.live.positionSize !== "min" &&
      s.live.positionSize !== "risk"
    )
      throw new Error('position size: "lanes", "min" or "risk"');
    if (s.live.positionSize === "risk" && s.live.laneOrders === true)
      throw new Error('position size "risk" needs control orders (laneOrders off): lane orders size every lane one unit');
    if (s.live.riskPerPositionPct !== undefined)
      num(s.live.riskPerPositionPct, 0.0005, 0.05, "risk per position (fraction of B)");
    if (s.live.laneOrders !== undefined && typeof s.live.laneOrders !== "boolean")
      throw new Error("laneOrders: true or false");
    if (s.live.maxVenueOrders !== undefined)
      int(s.live.maxVenueOrders, "venue TP/SL orders at most");
    if (s.live.maxBackstopLossPct !== undefined)
      num(s.live.maxBackstopLossPct, 0, 1, "worst-case loss budget (fraction of balance)");
    if (s.live.maxPositionX !== undefined)
      num(s.live.maxPositionX, 0, 50, "position limit × balance");
    // Absolute per-position dollar ceilings were removed; accept only the legacy disabled value.
    if (s.live.maxNotionalUsd !== undefined && s.live.maxNotionalUsd !== 0)
      throw new Error(
        "fixed USD per-position ceilings are disabled; size with account-balance volume factors",
      );
    num(s.live.rebalancePct, 0, 1, "rebalance threshold");
    if (s.live.marginMode !== undefined && !["cross", "isolated"].includes(s.live.marginMode))
      throw new Error("margin mode must be cross or isolated");
    if (s.live.positionMode !== undefined && !["hedge", "oneway"].includes(s.live.positionMode))
      throw new Error("position mode must be hedge or oneway");
    if (s.live.leverage !== undefined && s.live.leverage !== "max")
      num(s.live.leverage, 1, 150, "leverage");
    if (s.live.minFreeMargin !== undefined)
      num(s.live.minFreeMargin, 0, 1_000_000, "min free margin");
    if (
      s.live.openPaused !== undefined &&
      typeof s.live.openPaused !== "boolean" &&
      typeof s.live.openPaused !== "string"
    )
      throw new Error("live: open paused must be true / false or a reason");
  }
  if (s.toggles)
    for (const [k, v] of Object.entries(s.toggles))
      if (typeof v !== "boolean") throw new Error(`toggle ${k} must be boolean`);
  if (s.exitStrategy) {
    const e = s.exitStrategy;
    if (e.validationSlices !== undefined && (!Number.isInteger(e.validationSlices) || e.validationSlices < 1 || e.validationSlices > 4))
      throw new Error("Exit validation slices: integer from 1 to 4");
    if (e.signalRanges !== undefined) {
      if (!Array.isArray(e.signalRanges) || e.signalRanges.length > 6)
        throw new Error("Signal Exit ranges: at most 6 additional fits");
      const seen = new Set<string>();
      for (const range of e.signalRanges) {
        if (!range || typeof range !== "object" || !["extrema", "close"].includes(range.basis))
          throw new Error("Signal Exit range basis: extrema or close");
        if (!Number.isFinite(range.holdH) || !Number.isFinite(range.distance))
          throw new Error("Signal Exit range requires finite horizon and distance");
        num(range.holdH, 0.5, 96, "Signal Exit range hours");
        num(range.distance, 1, 3, "Signal Exit distance multiplier");
        const key = `${range.holdH}|${range.distance}|${range.basis}`;
        if (seen.has(key)) throw new Error("Duplicate Signal Exit range");
        seen.add(key);
      }
    }
    if (e.enabled !== undefined && typeof e.enabled !== "boolean")
      throw new Error("historic exit strategy: on / off");
    if (e.timeframes !== undefined) {
      if (
        !Array.isArray(e.timeframes) ||
        e.timeframes.length < 1 ||
        e.timeframes.length > 4 ||
        e.timeframes.some((tf) => ![1, 5, 15, 30].includes(tf)) ||
        new Set(e.timeframes).size !== e.timeframes.length
      )
        throw new Error("historic exit timeframes: choose 1–4 unique lanes from 1, 5, 15, 30");
      // Exit lanes are filtered against the initialized universe at runtime. Retaining a selected
      // lane while the system lane list changes lets operators switch system lanes back on later.
    }
    for (const key of [
      "includeTactics",
      "includeRelations",
      "includeMicro",
      "includeCombined",
    ] as const)
      if (e[key] !== undefined && typeof e[key] !== "boolean")
        throw new Error(`historic exit ${key}: on / off`);
    num(e.lookbackH, 0, 720, "historic exit lookback (hours)");
    num(e.trainFraction, 0.5, 0.8, "historic exit fit fraction");
    num(e.minEntries, 5, 1000, "historic exit fit entries");
    num(e.minValidationTrades, 2, 500, "historic exit validation closes");
    num(e.minPf, 1.05, 10, "historic exit validation PF");
    num(e.minGreenHourShare, 0, 1, "historic exit minimum green-hour share");
    num(e.maxDdr, 0, 10, "historic exit max drawdown / net ratio");
    num(e.holdH, 0.5, 96, "historic exit maximum hold (hours)");
    num(e.maxConfigsPerPair, 6, 512, "historic exit configs per pair");
    num(e.minTp, 0.001, 0.5, "historic exit minimum TP");
    num(e.maxTp, 0.002, 1, "historic exit maximum TP");
    num(e.maxSl, 0.005, 1, "historic exit maximum SL");
    if (e.minTp !== undefined && e.maxTp !== undefined && e.minTp >= e.maxTp)
      throw new Error("historic exit TP floor must be below its cap");
    int(e.minEntries, "historic exit fit entries");
    int(e.minValidationTrades, "historic exit validation closes");
    int(e.maxConfigsPerPair, "historic exit configs per pair");
    const list = (xs: unknown, lo: number, hi: number, name: string) => {
      if (xs === undefined) return;
      if (!Array.isArray(xs) || xs.length < 1 || xs.length > 4)
        throw new Error(`${name}: 1–4 values`);
      for (const x of xs) num(x, lo, hi, name);
    };
    list(e.quantiles, 0.2, 0.95, "historic exit MFE quantile");
    list(e.stopQuantiles, 0.2, 0.95, "historic exit MAE quantile");
    list(e.trailShares, 0.1, 0.95, "historic exit trail share");
    list(e.stopMultiples, 0.25, 5, "historic exit stop multiple");
    const q = e.quantiles?.length ?? 2;
    const stopQ = e.stopQuantiles?.length ?? 2;
    const gridN = Math.max(
      q * (e.stopMultiples?.length ?? 2),
      q * stopQ,
      q * stopQ * (e.trailShares?.length ?? 2),
    );
    if (gridN > 16)
      throw new Error(
        `historic exit config grid too large (${gridN}, max 16 per config family and direction)`,
      );
  }
  if (s.tactics) {
    for (const k of [
      "session",
      "volRegime",
      "trendStrength",
      "chopRegime",
      "onRun",
      "cooldown",
    ] as const)
      if (s.tactics[k] !== undefined && typeof s.tactics[k] !== "boolean")
        throw new Error(`tactic ${k} must be boolean`);
    num(s.tactics.cooldownBars, 0, 96, "cooldown bars");
  }
  if (s.disabledKinds !== undefined) {
    if (
      !Array.isArray(s.disabledKinds) ||
      s.disabledKinds.some((k) => typeof k !== "string" || !/^[a-z]+$/.test(k))
    )
      throw new Error("disabledKinds: list of indication types");
  }
  if (s.focus !== undefined) {
    if (!Array.isArray(s.focus) || s.focus.length > MAX_FOCUS_PAIRS)
      throw new Error(`focus: up to ${MAX_FOCUS_PAIRS} bot|indication pairs`);
    for (const f of s.focus)
      if (typeof f !== "string" || !/^[a-z]+\|[a-z0-9.@-]+$/.test(f))
        throw new Error(`focus entry ${String(f)} must be bot|indication`);
  }
  if (s.pinned !== undefined) {
    if (!Array.isArray(s.pinned) || s.pinned.length > 80)
      throw new Error("pinned: up to 80 bot|indication pairs");
    for (const f of s.pinned)
      if (typeof f !== "string" || !/^[a-z]+\|[a-z0-9.@-]+$/.test(f))
        throw new Error(`pinned entry ${String(f)} must be bot|indication`);
  }
  if (s.block) {
    num(s.block.ratio, 0, 2, "block ratio");
    num(s.block.sharedRatio, 0, 2, "block Shared ratio");
    if (s.block.sourceRatios !== undefined) {
      if (!s.block.sourceRatios || typeof s.block.sourceRatios !== "object" || Array.isArray(s.block.sourceRatios))
        throw new Error("block relation ratios must be an object");
      for (const [key, value] of Object.entries(s.block.sourceRatios)) {
        if (!["config", "overall", "symbol", "direction", "indication", "type"].includes(key))
          throw new Error("unknown Block relation ratio");
        num(value, 0, 10, `block ${key} ratio multiplier`);
      }
    }
    if (s.block.holdUntilNet !== undefined && typeof s.block.holdUntilNet !== "boolean")
      throw new Error("block retain until net: on / off");
    if (
      s.block.historySource !== undefined &&
      !["accepted-orders", "real-candidates"].includes(s.block.historySource)
    )
      throw new Error("block history source: accepted-orders or real-candidates");
    num(s.block.maxLevel, 1, 12, "block max level");
    num(s.block.minActiveLevel, 1, 12, "block active level");
    num(s.block.maxMult, 1, 8, "block max multiple (stack ≤ 8×)");
    if (
      s.block.mode !== undefined &&
      s.block.mode !== "shared" &&
      s.block.mode !== "additive" &&
      s.block.mode !== "overall"
    )
      throw new Error("block type must be shared, additive or overall");
    // shared and overall judge one source's level (at most maxLevel): an Active minimum above it never trades
    if (
      s.block.mode !== "additive" &&
      typeof s.block.minActiveLevel === "number" &&
      typeof s.block.maxLevel === "number" &&
      s.block.minActiveLevel > s.block.maxLevel
    )
      throw new Error("block active level must not exceed the max level (shared / overall)");
    if (s.block.signalsOwn !== undefined && typeof s.block.signalsOwn !== "boolean")
      throw new Error("block signals own: on / off");
    num(s.block.pause, 0, 12, "block pause (0 = none)");
    num(s.block.steps, 0, 12, "block volume steps (0 = continuous)");
    if (s.block.window !== undefined)
      num(s.block.window, 1, 500, "block pooled-source window (closes per level)");
    if (s.block.windowAuto !== undefined && typeof s.block.windowAuto !== "boolean")
      throw new Error("block window auto: on / off");
    if (s.block.windowCandidates !== undefined) {
      if (
        !Array.isArray(s.block.windowCandidates) ||
        s.block.windowCandidates.length < 1 ||
        s.block.windowCandidates.length > 12
      )
        throw new Error("block window candidates: 1–12 windows");
      for (const w of s.block.windowCandidates) num(w, 1, 500, "block window candidate");
    }
    if (s.block.windowLookback !== undefined) num(s.block.windowLookback, 30, 5000, "block window lookback");
    if (s.block.stepFloor !== undefined && typeof s.block.stepFloor !== "boolean")
      throw new Error("block step floor: on / off");
    if (s.block.windowHours !== undefined) num(s.block.windowHours, 0, 168, "block activity window (hours, 0 = off)");
    if (s.block.levelMinWin !== undefined) num(s.block.levelMinWin, 0, 1, "block level win share (0 = off)");
    for (const k of ["poolSignals", "poolDedupe", "sideKeys"] as const)
      if (s.block[k] !== undefined && typeof s.block[k] !== "boolean") throw new Error(`block ${k}: on / off`);
    num(s.block.increase, 0.05, 1, "block increase");
    const span = (pair: unknown, lo: number, hi: number, name: string) => {
      if (pair === undefined) return;
      if (!Array.isArray(pair) || pair.length !== 2) throw new Error(`${name}: min and max`);
      num(pair[0], lo, hi, name);
      num(pair[1], lo, hi, name);
      if (pair[1] < pair[0]) throw new Error(`${name}: max must be ≥ min`);
    };
    if (s.block.ranges) {
      span(s.block.ranges.levels, 1, 12, "block level range");
      span(s.block.ranges.volRatio, 0.05, 2, "block volume-ratio range");
      span(s.block.ranges.steps, 0, 12, "block step range");
      span(s.block.ranges.increase, 0.05, 1, "block increase range");
      span(s.block.ranges.pause, 0, 12, "block pause range");
    }
    if (s.block.sources !== undefined) {
      if (typeof s.block.sources !== "object" || s.block.sources === null)
        throw new Error("block sources: object of switches");
      for (const [k, v] of Object.entries(s.block.sources))
        if (
          !["config", "overall", "symbol", "direction", "indication", "type"].includes(k) ||
          typeof v !== "boolean"
        )
          throw new Error(`block source ${k} must be a known source with an on/off value`);
    }
    // the ranges Block never raises: the range tags, and "wide" for the untagged grid (as live.excludeRanges)
    if (s.block.excludeRanges !== undefined) {
      const ok = ["wide", "mc", "mn", "mp", "sh", "gn", "lg"];
      if (
        !Array.isArray(s.block.excludeRanges) ||
        s.block.excludeRanges.some((r) => !ok.includes(r))
      )
        throw new Error(`block excluded ranges: a list of ${ok.join(", ")}`);
    }
  }
  if (s.fees) {
    num(s.fees.taker, 0, 0.01, "taker fee");
    num(s.fees.maker, 0, 0.01, "maker fee");
    num(s.fees.slippage, 0, 0.02, "slippage");
  }
  if (s.adjust) {
    const a = s.adjust;
    if (a.enabled !== undefined && typeof a.enabled !== "boolean")
      throw new Error("adjust.enabled must be boolean");
    if (a.autoCost !== undefined && typeof a.autoCost !== "boolean")
      throw new Error("adjust.autoCost must be boolean");
    num(a.window, 5, 100, "adjust window");
    if (a.window !== undefined && !Number.isInteger(a.window))
      throw new Error("adjust window must be a whole number");
    num(a.triggerPf, 0.5, 2, "adjust trigger PF");
    num(a.recoverPf, 0.5, 3, "adjust recover PF");
    num(a.slStep, 0.0001, 0.02, "SL step");
    num(a.slMax, 0.001, 0.2, "SL max");
    num(a.trailStep, 0.0001, 0.02, "trail step");
    num(a.trailMax, 0.001, 0.2, "trail max");
    num(a.pauseH, 0, 168, "pause hours");
    if (a.triggerPf !== undefined && a.recoverPf !== undefined && a.recoverPf < a.triggerPf)
      throw new Error("recover PF must be ≥ trigger PF");
    num(a.slScale, 0, 2, "adjust SL scale per level");
    num(a.trailScale, 0, 2, "adjust trail scale per level");
    num(a.scaleMax, 1, 5, "adjust scale max");
    num(a.stepEvery, 1, 100, "adjust closes per step");
    if (a.stepEvery !== undefined && !Number.isInteger(a.stepEvery))
      throw new Error("adjust closes per step must be a whole number");
  }
  if (s.axis) {
    volumeFactor(s.axis.volumeFactor, "axis set volume factor");
    num(s.axis.levels, 1, 8, "axis levels");
    num(s.axis.spacing, 0.1, 5, "axis spacing (ATR)");
    num(s.axis.ratio, 0.1, 5, "axis rung ratio");
    num(s.axis.minDisp, 0, 10, "axis min displacement");
    num(s.axis.maxDisp, 0.1, 20, "axis max displacement");
    num(s.axis.center, 5, 400, "axis EMA period");
    if (s.axis.centerMin !== undefined)
      num(s.axis.centerMin, 0, 1440, "axis EMA period (minutes; 0 = bars)");
    if (s.axis.mode !== undefined && !["revert", "desk"].includes(s.axis.mode))
      throw new Error("axis mode: revert or desk");
    const ranges = ["atr", "linear", "geo", "fib", "volume"];
    if (s.axis.range !== undefined && !ranges.includes(s.axis.range))
      throw new Error("axis range: atr, linear, geo, fib or volume");
    if (s.axis.ranges !== undefined) {
      if (
        !Array.isArray(s.axis.ranges) ||
        s.axis.ranges.length < 1 ||
        !s.axis.ranges.every((r) => ranges.includes(r))
      )
        throw new Error("axis ranges: one or more of atr, linear, geo, fib, volume");
    }
    // desk mode (Stable-02): SL_ATR 0.2–2, TP_SL_RATIOS 0.2–3, TRAIL_PCTS 0.4–2.4
    num(s.axis.slAtr, 0.2, 2, "axis desk SL (ATR)");
    num(s.axis.tpRatio, 0.2, 3, "axis desk TP / SL ratio");
    if (s.axis.perRange !== undefined && typeof s.axis.perRange !== "boolean")
      throw new Error("axis per range: on / off");
    num(s.axis.trailPct, 0.4, 2.4, "axis desk trailing %");
    num(s.axis.expiry, 0, 500, "axis rung expiry (bars)");
    int(s.axis.expiry, "axis rung expiry");
    if (s.axis.hybrid !== undefined && typeof s.axis.hybrid !== "boolean")
      throw new Error("axis hybrid: on / off");
    if (s.axis.modes !== undefined) {
      if (
        !Array.isArray(s.axis.modes) ||
        s.axis.modes.length < 1 ||
        !s.axis.modes.every((m) => m === "revert" || m === "desk")
      )
        throw new Error("axis modes: one or more of revert, desk");
    }
    if (s.axis.hybrids !== undefined) {
      if (
        !Array.isArray(s.axis.hybrids) ||
        s.axis.hybrids.length < 1 ||
        !s.axis.hybrids.every((h) => typeof h === "boolean")
      )
        throw new Error("axis hybrids: one or more of on / off");
    }
    if (s.axis.levelsSet !== undefined) {
      if (
        !Array.isArray(s.axis.levelsSet) ||
        s.axis.levelsSet.length < 1 ||
        s.axis.levelsSet.length > 16
      )
        throw new Error("axis ladder depths: 1–16 values");
      for (const l of s.axis.levelsSet) {
        num(l, 1, 8, "axis ladder depth");
        int(l, "axis ladder depth");
      }
    }
    if (
      s.axis.minDisp !== undefined &&
      s.axis.maxDisp !== undefined &&
      s.axis.minDisp >= s.axis.maxDisp
    )
      throw new Error("axis min displacement must be below max");
  }
  if (s.relate) {
    if (s.relate.enabled !== undefined && typeof s.relate.enabled !== "boolean")
      throw new Error("Relate enabled: on / off");
    if (s.relate.auto !== undefined && typeof s.relate.auto !== "boolean")
      throw new Error("Relate Auto mode: on / off");
    if (s.relate.mode !== undefined && s.relate.mode !== "shared" && s.relate.mode !== "additive")
      throw new Error("Relate mode must be shared or additive");
    if (s.relate.ratio !== undefined) num(s.relate.ratio, 0.2, 6, "Relate ratio");
    if (s.relate.ratio !== undefined && Math.abs(s.relate.ratio * 5 - Math.round(s.relate.ratio * 5)) > 1e-8)
      throw new Error("Relate ratio must use 0.2 increments");
    if (s.relate.steps !== undefined) {
      int(s.relate.steps, "Relate steps");
      num(s.relate.steps, 2, 15, "Relate steps");
    }
    if (s.relate.activeStep !== undefined) {
      int(s.relate.activeStep, "Relate Active step");
      num(s.relate.activeStep, 0, 6, "Relate Active step");
    }
    if (s.relate.minPf !== undefined) num(s.relate.minPf, 0, 100, "Relate minimum PF");
    if (s.relate.lastN !== undefined) {
      int(s.relate.lastN, "Relate last-N");
      num(s.relate.lastN, 60, 250, "Relate last-N");
    }
    if (s.relate.minTrades !== undefined) {
      int(s.relate.minTrades, "Relate minimum trades");
      num(s.relate.minTrades, 60, 250, "Relate minimum trades");
    }
    if (s.relate.minTrades !== undefined && s.relate.lastN !== undefined && s.relate.minTrades > s.relate.lastN)
      throw new Error("Relate minimum trades must not exceed last-N");
    if (s.relate.maxStack !== undefined) {
      int(s.relate.maxStack, "Relate maximum stack");
      num(s.relate.maxStack, 1, 250, "Relate maximum stack");
    }
    if (s.relate.sources !== undefined) {
      if (!s.relate.sources || typeof s.relate.sources !== "object" || Array.isArray(s.relate.sources))
        throw new Error("Relate sources must be an object of switches");
      const relateSources = ["config", "overall", "symbol", "direction", "indication", "strategy", "coordination", "range"];
      for (const [key, value] of Object.entries(s.relate.sources))
        if (!relateSources.includes(key) || typeof value !== "boolean")
          throw new Error(`Relate source ${key} must be a known source with an on/off value`);
    }
  }
  if (s.dca) {
    num(s.dca.levels, 1, 4, "dca levels (stack ≤ 5 stages: base + 4)");
    num(s.dca.step, 0.001, 0.1, "dca step");
    num(s.dca.maxDistance, 0, 0.1, "dca maximum addition distance");
    if (s.dca.addRatio !== undefined) num(s.dca.addRatio, 0.1, 2.5, "dca addition (original base units)");
    if (s.dca.stepOfTp !== undefined) num(s.dca.stepOfTp, 0, 5, "dca step (× target)");
    if (s.dca.stopGap !== undefined) num(s.dca.stopGap, 0, 5, "dca stop gap (steps)");
    if (s.dca.slOfTp !== undefined) num(s.dca.slOfTp, 0.25, 5, "dca stop (× target)");
    if (s.dca.tp !== undefined) {
      if (!Array.isArray(s.dca.tp) || s.dca.tp.length > 12)
        throw new Error("dca targets: up to 12");
      for (const x of s.dca.tp) num(x, 0.002, 0.2, "dca target");
    }
  }
  if (s.grid) {
    // a generous list length (operator: no working caps — the variant ceiling is the real guard)
    const list = (xs: unknown, lo: number, hi: number, name: string) => {
      if (xs === undefined) return;
      if (!Array.isArray(xs) || xs.length < 1 || xs.length > 64)
        throw new Error(`${name}: 1–64 values`);
      for (const x of xs) num(x, lo, hi, name);
    };
    // the wide grid may be empty (the position-cost ranges cover its targets)
    if (!(Array.isArray(s.grid.tp) && s.grid.tp.length === 0))
      list(s.grid.tp, 0.002, 0.2, "grid TP");
    list(s.grid.slOfTp, 0.2, 5, "grid SL×TP");
    list(s.grid.trailOfTp, 0, 1, "grid trail share");
    list(s.grid.holdH, 0.25, 72, "grid hold");
    num(s.grid.minTrail, 0, 0.1, "min trail");
    num(s.grid.minSl, 0, 0.2, "min SL");
    if (s.grid.maxSl !== undefined) num(s.grid.maxSl, 0.005, 0.2, "max SL");
    if (s.grid.maxTrail !== undefined) num(s.grid.maxTrail, 0.003, 0.2, "max trail");
    num(s.grid.trailStep, 0.1, 1, "trail step");
    if (s.grid.trailingOnly !== undefined && typeof s.grid.trailingOnly !== "boolean")
      throw new Error("independent trailing-only grid: on / off");
    if (s.grid.trailFree !== undefined && typeof s.grid.trailFree !== "boolean")
      throw new Error("trail free: on / off");
    // the levers every range shares (RangeGrid): checked the same way for Micro, Minimal, Short, General and Long
    const rangeShared = (r: unknown, name: string) => {
      const g = r as {
        volumeFactor?: unknown;
        trailSlOfTp?: unknown;
        minSl?: unknown;
        minTrail?: unknown;
        minTf?: unknown;
        minSlEval?: unknown;
        ownBase?: unknown;
        baseBest?: unknown;
      };
      volumeFactor(g.volumeFactor, `${name} volume factor`);
      // 0.2 like the stop ratios: General / Long trail at every stop of their 0.25–1.5 ladder (13 Oct)
      num(g.trailSlOfTp, 0.2, 5, `${name} trailing stop ×TP`);
      num(g.minSl, 0, 0.2, `${name} min SL`);
      num(g.minTrail, 0, 0.1, `${name} min trail`);
      num(g.minTf, 0, 240, `${name} shortest lane (minutes)`);
      if ((g as { maxHoldMin?: unknown }).maxHoldMin !== undefined)
        num((g as { maxHoldMin?: unknown }).maxHoldMin, 1, 1440, `${name} max hold time (minutes)`);
      if (g.minSlEval !== undefined) num(g.minSlEval, 0.0005, 0.05, `${name} evaluation min SL`);
      for (const [k, v] of [
        ["own Base cell (ownBase)", g.ownBase],
        ["best-cell Base (baseBest)", g.baseBest],
      ] as const)
        if (v !== undefined && typeof v !== "boolean") throw new Error(`${name} ${k}: on / off`);
    };
    // the three levers only Micro reads (MicroGrid). On another range the engine would ignore them, so they are
    // refused here instead: a setting that is accepted and then does nothing is the one thing a desk cannot see.
    const microOnly = (r: unknown, name: string) => {
      const g = r as {
        ownInds?: unknown;
        tpNetOfCost?: unknown;
        minNetOfCost?: unknown;
        minSlNet?: unknown;
      };
      for (const k of ["ownInds", "tpNetOfCost", "minNetOfCost", "minSlNet"] as const)
        if (g[k] !== undefined)
          throw new Error(`${name} ${k}: only the Micro range reads it (set it on grid.micro)`);
    };
    const range = (r: unknown, name: string) => {
      if (!r || typeof r !== "object") return;
      const g = r as { tp?: unknown; slOfTp?: unknown; trailOfTp?: unknown };
      list(g.tp, 0.002, 0.2, `${name} TP`);
      list(g.slOfTp, 0.2, 5, `${name} SL×TP`);
      list(g.trailOfTp, 0, 1, `${name} trail share`);
      rangeShared(r, name);
      microOnly(r, name);
    };
    const short = s.grid.short;
    const minimal = s.grid.minimal;
    const general = s.grid.general;
    const long = s.grid.long;
    range(short, "short");
    range(minimal, "minimal");
    if (minimal && typeof minimal === "object") {
      const mi = (minimal as { microInds?: unknown }).microInds;
      if (mi !== undefined && typeof mi !== "boolean")
        throw new Error("minimal microInds: on / off");
    }
    for (const [r, name] of [
      [short, "short"],
      [general, "general"],
      [long, "long"],
    ] as const)
      if (r && typeof r === "object" && (r as { microInds?: unknown }).microInds !== undefined)
        throw new Error(
          `${name} microInds: only the Minimal range reads it (set it on grid.minimal)`,
        );
    range(general, "general");
    range(long, "long");
    const micro = s.grid.micro;
    if (micro && typeof micro === "object") {
      const wide = (xs: unknown, lo: number, hi: number, name: string, max: number) => {
        // a patch may carry one lever (as on the other ranges): an absent list keeps the current one
        if (xs === undefined) return;
        if (!Array.isArray(xs) || xs.length < 1 || xs.length > max)
          throw new Error(`${name}: 1–${max} values`);
        for (const x of xs) num(x, lo, hi, name);
      };
      // tp: the net target after the round-trip cost (tpNetOfCost, default on) or the price target itself
      wide(micro.tp, 0.001, 0.2, "micro TP", 16);
      wide(micro.slOfTp, 0.5, 5, "micro SL×TP", 24);
      if (micro.tpNetOfCost !== undefined && typeof micro.tpNetOfCost !== "boolean")
        throw new Error("micro tpNetOfCost: true or false");

      wide(micro.trailOfTp, 0, 1, "micro trail share", 8);
      // Micro takes every shared lever on the same bounds as the other ranges (its own targets and stops are wider)
      rangeShared(micro, "micro");
      const mx = micro as { minNetOfCost?: unknown };
      if (mx.minNetOfCost !== undefined)
        num(mx.minNetOfCost, 0, 10, "micro min net of cost (× cost)");
      const ms = micro as { minSlNet?: unknown };
      if (ms.minSlNet !== undefined) num(ms.minSlNet, 0, 0.05, "micro min SL net of cost");
      // the trail list may be [0]: a plain-only Micro grid was unreachable (two trailing configs were required)
      if (micro.trailOfTp !== undefined && !(micro.trailOfTp as unknown[]).length)
        throw new Error("micro: at least one trail share (0 = no trail)");
    }
    const holdN = s.grid.holdH?.length ?? 2;
    const cells = (
      r:
        | { tp?: readonly unknown[]; slOfTp?: readonly unknown[]; trailOfTp?: readonly unknown[] }
        | false
        | undefined,
    ) =>
      r && r.tp && r.slOfTp && r.trailOfTp
        ? r.tp.length * r.slOfTp.length * r.trailOfTp.length * holdN
        : 0;
    const n =
      (s.grid.tp?.length ?? 4) *
        (s.grid.slOfTp?.length ?? 4) *
        (s.grid.trailOfTp?.length ?? 3) *
        holdN +
      cells(short) +
      cells(minimal) +
      cells(general) +
      cells(long) +
      cells(micro);
    const plus = s.grid.minimalPlus;
    let plusN = 0;
    if (plus) {
      volumeFactor(plus.volumeFactor, "minimal plus volume factor");
      if (plus.enabled !== undefined && typeof plus.enabled !== "boolean")
        throw new Error("minimal plus: on / off");
      num(plus.lastN, 50, 500, "minimal plus last N");
      if (plus.lastN !== undefined && !Number.isInteger(plus.lastN))
        throw new Error("minimal plus last N must be a whole number");
      num(plus.minPf, 1.05, 5, "minimal plus min PF");
      if (plus.cells !== undefined) {
        if (!Array.isArray(plus.cells) || plus.cells.length > 80)
          throw new Error("minimal plus: up to 80 selected cells");
        for (const c of plus.cells) {
          num(c?.tp, 0.002, 0.2, "minimal plus cell TP");
          num(c?.sl, 0.001, 0.2, "minimal plus cell SL");
          num(c?.trail, 0, 0.1, "minimal plus cell trail");
        }
      }
      if (plus.enabled === true && !(plus.cells && plus.cells.length))
        throw new Error("minimal plus is on but no cell has cleared the last-N gate");
      if (plus.enabled === true && plus.cells) plusN = plus.cells.length * holdN;
    }
    if (n + plusN > GRID_VARIANTS_MAX)
      throw new Error(`protect grid too large (${n + plusN} variants, max ${GRID_VARIANTS_MAX})`);
    if (s.grid.baseBest !== undefined && typeof s.grid.baseBest !== "boolean")
      throw new Error("grid baseBest: true or false");
    for (const k of ["micro", "minimal", "short", "general", "long"] as const) {
      const r = s.grid[k];
      if (r && r.baseBest !== undefined && typeof r.baseBest !== "boolean")
        throw new Error(`${k} baseBest: true or false`);
    }
    const rg = s.grid.rangeGate;
    if (rg !== undefined) {
      if (!rg || typeof rg !== "object") throw new Error("range gate: object");
      if (rg.enabled !== undefined && typeof rg.enabled !== "boolean")
        throw new Error("range gate: on / off");
      num(rg.lastN, 50, 1000, "range gate last N");
      if (rg.lastN !== undefined && !Number.isInteger(rg.lastN))
        throw new Error("range gate last N must be a whole number");
      num(rg.minPf, 1.05, 5, "range gate min PF");
    }
    if (s.grid.baseTrailCells !== undefined && typeof s.grid.baseTrailCells !== "boolean")
      throw new Error("Base trailed cells: on / off");
    if (s.grid.baseCells !== undefined && typeof s.grid.baseCells !== "boolean")
      throw new Error("Base cells: on / off");
    if (s.grid.allSets !== undefined && typeof s.grid.allSets !== "boolean")
      throw new Error("all config sets: on / off");
    if (s.grid.baseRanges !== undefined && typeof s.grid.baseRanges !== "boolean")
      throw new Error("Base-passed ranges only: on / off");
    const rf = s.grid.rangeFit;
    if (rf !== undefined) {
      if (!rf || typeof rf !== "object") throw new Error("range fit: object");
      if (rf.enabled !== undefined && typeof rf.enabled !== "boolean")
        throw new Error("range fit: on / off");
      num(rf.lo, 0.05, 2, "range fit low");
      num(rf.hi, 0.5, 10, "range fit high");
      if (rf.lo !== undefined && rf.hi !== undefined && rf.lo >= rf.hi)
        throw new Error("range fit: low below high");
      num(rf.keep, 1, 8, "range fit targets kept");
    }
    if (s.grid.rangeSeats !== undefined && typeof s.grid.rangeSeats !== "boolean")
      throw new Error("range seats: on / off");
  }
  if (s.signals) {
    const g = s.signals;
    const bool = (v: unknown, name: string) => {
      if (v !== undefined && typeof v !== "boolean") throw new Error(`${name}: on / off`);
    };
    const list = (xs: unknown, lo: number, hi: number, name: string) => {
      if (xs === undefined) return;
      if (!Array.isArray(xs) || xs.length < 1 || xs.length > 64)
        throw new Error(`${name}: 1–64 values`);
      for (const x of xs) num(x, lo, hi, name);
    };
    bool(g.enabled, "signals");
    if (g.count !== undefined && g.count !== 0) {
      num(g.count, 10, 10_000, "active signals");
      if (g.count % 10 !== 0) throw new Error("active signals: steps of 10");
    }
    if (g.sources !== undefined) {
      if (typeof g.sources !== "object" || g.sources === null)
        throw new Error("signal sources: on / off per source");
      for (const [k, v] of Object.entries(g.sources)) bool(v, `signal source ${k}`);
    }
    if (g.sourcesMode !== undefined && g.sourcesMode !== "deny" && g.sourcesMode !== "allow")
      throw new Error("signal sources mode: deny (missing = on) or allow (only listed sources)");
    if (g.ranges) {
      bool(g.ranges.short, "short range");
      bool(g.ranges.medium, "medium range");
      if (g.ranges.short === false && g.ranges.medium === false)
        throw new Error("signals: at least one range");
    }
    if (g.rangeVolumeFactors !== undefined) {
      if (!g.rangeVolumeFactors || typeof g.rangeVolumeFactors !== "object")
        throw new Error("signal range volume factors: short and medium ratios");
      volumeFactor(g.rangeVolumeFactors.short, "Signal short volume factor");
      volumeFactor(g.rangeVolumeFactors.medium, "Signal medium volume factor");
    }
    if (g.lanes !== undefined) {
      if (
        !Array.isArray(g.lanes) ||
        !g.lanes.length ||
        !g.lanes.every((x) => [1, 5, 15, 30].includes(x))
      )
        throw new Error("signal lanes: any of 1, 5, 15, 30 (minutes)");
    }
    list(g.normal?.tp, 0.002, 0.2, "signal Normal TP");
    list(g.normal?.slOfTp, 0.2, 5, "signal Normal SL×TP");
    list(g.trailing?.tp, 0.002, 0.2, "signal Trailing TP");
    list(g.trailing?.trailOfTp, 0.05, 1, "signal trail share");
    num(g.trailing?.slOfTp, 0.2, 5, "signal Trailing SL×TP");
    if (g.trailRatios !== undefined) {
      list(g.trailRatios, 0.1, 2, "signal peak-gap ratios");
      if (g.trailRatios.length > 64 || new Set(g.trailRatios).size !== g.trailRatios.length)
        throw new Error("signal peak-gap ratios: at most 64 distinct values");
    }
    if (g.trailMax !== undefined) num(g.trailMax, 0.002, 0.03, "Signal maximum trailing from entry");
    if (g.trailingOnly) {
      bool(g.trailingOnly.enabled, "signal Trailing only sets");
      list(g.trailingOnly.sl, 0.002, 0.2, "signal Trailing only SL");
      list(g.trailingOnly.trail, 0.002, 0.1, "signal Trailing only activation");
      for (const xs of [g.trailingOnly.sl, g.trailingOnly.trail])
        if (xs !== undefined && xs.length > 64)
          throw new Error("signal Trailing only ranges: at most 64 values per list");
      num(g.trailingOnly.trailStep, 0.1, 2, "signal Trailing only trail step");
      const n =
        (g.trailingOnly.sl?.length ?? 3) *
        (g.trailingOnly.trail?.length ?? 3) *
        (g.trailRatios?.length ?? 1);
      if (n > 256) throw new Error(`signal Trailing only grid too large (${n} configs, max 256)`);
    }
    num(g.holdH, 0.5, 96, "signal hold");
    if (g.exits !== undefined && !["pct", "atr", "both"].includes(g.exits))
      throw new Error("signal exits: pct, atr or both");
    if (g.atr) {
      list(g.atr.sl, 0.2, 2, "signal ATR stop (× ATR)");
      list(g.atr.tpRatio, 0.2, 3, "signal ATR target ratio (× stop)");
      if (g.atr.trail !== undefined) {
        if (!Array.isArray(g.atr.trail) || g.atr.trail.length > 16)
          throw new Error("signal ATR trail: 0–16 values");
        for (const x of g.atr.trail) num(x, 0.4, 2.4, "signal ATR trail (%)");
      }
      num(g.atr.holdBars, 0, 384, "signal ATR hold (15m bars)");
      int(g.atr.holdBars, "signal ATR hold (15m bars)");
      const n =
        (g.atr.sl?.length ?? 3) * (g.atr.tpRatio?.length ?? 3) * (1 + (g.atr.trail?.length ?? 1));
      if (n > 2400) throw new Error(`signal ATR grid too large (${n} configs, max 2400)`);
    }
    if (g.hist) {
      bool(g.hist.enabled, "signal historic trailing configs");
      list(g.hist.quantiles, 0.2, 0.95, "signal historic target quantile");
      list(g.hist.trailOfTp, 0.1, 0.95, "signal historic trail share");
      list(g.hist.slOfTp, 0.25, 5, "signal historic SL×TP");
      num(g.hist.minN, 5, 1000, "signal historic entries needed");
      num(g.hist.lookbackH ?? 0, 0, 720, "signal historic lookback (hours; 0 = the whole history)");
      int(g.hist.minN, "signal historic entries needed");
      const n =
        (g.hist.quantiles?.length ?? 2) *
        (g.hist.trailOfTp?.length ?? 3) *
        (g.hist.slOfTp?.length ?? 2);
      if (n > 1000) throw new Error(`signal historic grid too large (${n} configs, max 1000)`);
    }
    bool(g.guard?.enabled, "signal guard");
    num(g.guard?.lastN, 2, 50, "signal guard last N");
    num(g.minTrades, 1, 100, "signal min trades");
    int(g.guard?.lastN, "signal guard last N");
    int(g.minTrades, "signal min trades");
    if (g.rank !== undefined && !["drawdown", "lowdd", "net"].includes(g.rank))
      throw new Error("signal ranking: drawdown or net");
    num(g.minBlockShare, 0, 1, "signal min positive 4-hour block share");
    bool(g.validate, "signal validation on the latest hours");
    num(g.validateH, 2, 72, "signal validation window (h)");
    num(g.minSl, 0, 0.1, "signal minimum stop");
    num(g.minTrail, 0, 0.1, "signal minimum trailing distance");
    if (g.sourceGate) {
      bool(g.sourceGate.enabled, "source stability gate");
      num(g.sourceGate.days, 1, 14, "source gate days");
      num(g.sourceGate.minShare, 0, 1, "source gate positive-day share");
      num(g.sourceGate.minTrades, 1, 100, "source gate minimum orders");
    }
    if (g.cluster) {
      bool(g.cluster.enabled, "signal loss-cluster guard");
      num(g.cluster.windowMin, 5, 720, "loss-cluster window (min)");
      num(g.cluster.minLosses, 1, 1000, "loss-cluster min losses");
      num(g.cluster.lossShare, 0.3, 1, "loss-cluster loss share");
      int(g.cluster.minLosses, "loss-cluster min losses");
    }
    if (g.coordination) {
      const c = g.coordination;
      bool(c.enabled, "signals coordination");
      num(c.minSources, 2, 100, "signals coordination minimum sources");
      int(c.minSources, "signals coordination minimum sources");
      volumeFactor(c.volumeFactor, "signals coordination volume factor");
      if (c.count !== undefined && c.count !== 0) {
        num(c.count, 10, 10_000, "active coordination units");
        if (c.count % 10 !== 0) throw new Error("active coordination units: steps of 10");
      }
      if (c.ranges) {
        bool(c.ranges.short, "coordination Short range");
        bool(c.ranges.normal, "coordination Normal range");
        bool(c.ranges.long, "coordination Long range");
        if (
          c.enabled &&
          c.ranges.short === false &&
          c.ranges.normal === false &&
          c.ranges.long === false
        )
          throw new Error("signals coordination: at least one exit range");
      }
    }
    if (g.combinedVolumeFactors !== undefined) {
      if (
        typeof g.combinedVolumeFactors !== "object" ||
        g.combinedVolumeFactors === null ||
        Array.isArray(g.combinedVolumeFactors)
      )
        throw new Error(
          "indication volume factors: one 0.1–5 value in 0.1 steps per indication kind",
        );
      for (const [kind, value] of Object.entries(g.combinedVolumeFactors)) {
        if (!INDICATION_KINDS.includes(kind as (typeof INDICATION_KINDS)[number]))
          throw new Error(`unknown combined indication kind ${kind}`);
        volumeFactor(value, `${kind} volume factor`);
      }
    }
    if (g.accept) {
      bool(g.accept.enabled, "signal PF acceptance");
      num(g.accept.minPf, 1, 5, "signal acceptance minimum PF");
      num(g.accept.hours, 6, 336, "signal acceptance window (h)");
      num(g.accept.minTrades, 1, 200, "signal acceptance minimum trades");
      int(g.accept.hours, "signal acceptance window (h)");
      int(g.accept.minTrades, "signal acceptance minimum trades");
    }
    if (g.sideAccept) {
      bool(g.sideAccept.enabled, "signal direction acceptance");
      num(g.sideAccept.minPf, 1, 5, "signal direction acceptance minimum PF");
      num(g.sideAccept.hours, 6, 336, "signal direction acceptance window (h)");
      num(g.sideAccept.minTrades, 1, 1000, "signal direction acceptance minimum trades");
      int(g.sideAccept.hours, "signal direction acceptance window (h)");
      int(g.sideAccept.minTrades, "signal direction acceptance minimum trades");
    }
    if (g.filter) {
      num(g.filter.trendH, 0, 48, "signal trend filter (hours)");
      num(g.filter.volFloor, 0, 0.02, "signal volatility floor");
    }
    if (g.strategies) {
      bool(g.strategies.dca, "signal DCA sets");
      bool(g.strategies.axis, "signal Axis sets");
    }
    // checked whether or not the patch carries strategies (it was only checked inside them)
    bool(g.ownBase, "signals trade their own base");
    bool(g.baseGate, "signal Base gate");
    num(g.perSymbol, 0, 1000, "signal orders per symbol");
    num(g.maxOpen, 0, 100_000, "signal open orders");
    num(g.maxPositions, 0, 10_000, "signal max positions");
    int(g.maxPositions, "signal max positions");
    int(g.perSymbol, "signal orders per symbol");
    int(g.maxOpen, "signal open orders");
  }
}

/**
 * One two-window Base rule (Gates.baseWindows): split 2–6 blocks with need 1–split of them, a recent window of 1–336 h
 * (widen: on / off), a PF floor 0.5–3, 1–100 closes per judged window, the range tags it judges (a non-empty list
 * without "mp": Minimal plus is judged at the default cell, "wide"). It judges at least one window (split or recentH).
 */
function checkBaseWindowRule(r: unknown, name: string) {
  if (typeof r !== "object" || r === null || Array.isArray(r)) throw new Error(`${name}: an object`);
  const x = r as Record<string, unknown>;
  const KEYS = ["split", "need", "recentH", "widen", "minPf", "minN", "ranges"];
  for (const k of Object.keys(x)) if (!KEYS.includes(k)) throw new Error(`${name}: unknown key ${k}`);
  const num = (v: unknown, lo: number, hi: number, what: string, whole = false) => {
    if (v === undefined) return;
    if (typeof v !== "number" || !Number.isFinite(v) || v < lo || v > hi || (whole && !Number.isInteger(v)))
      throw new Error(`${name}: ${what} out of range (${lo}–${hi}${whole ? ", whole" : ""})`);
  };
  num(x.split, 2, 6, "split (blocks)", true);
  if (x.need !== undefined && x.split === undefined) throw new Error(`${name}: need goes with split`);
  num(x.need, 1, typeof x.split === "number" ? x.split : 6, "need (blocks that pass)", true);
  num(x.recentH, 1, 336, "recentH (hours)");
  if (x.widen !== undefined && typeof x.widen !== "boolean") throw new Error(`${name}: widen is true or false`);
  num(x.minPf, 0.5, 3, "minPf");
  num(x.minN, 1, 100, "minN (closes)", true);
  if (x.split === undefined && x.recentH === undefined) throw new Error(`${name}: set split, recentH or both`);
  if (x.ranges !== undefined) {
    const ok = ["mc", "mn", "sh", "gn", "lg", "wide"];
    // Minimal plus has no Base cell of its own: it is judged at the default cell, so "mp" would judge nothing ("wide"
    // judges it); an empty list judges nothing either (leave `ranges` out for every range)
    if (Array.isArray(x.ranges) && x.ranges.includes("mp"))
      throw new Error(`${name}: Minimal plus (mp) is judged at the default cell — list "wide" instead`);
    if (Array.isArray(x.ranges) && !x.ranges.length)
      throw new Error(`${name}: an empty range list judges nothing (leave ranges out for every range)`);
    if (!Array.isArray(x.ranges) || !x.ranges.every((t) => ok.includes(t)))
      throw new Error(`${name}: ranges are any of ${ok.join(", ")}`);
  }
}

/**
 * Cross-field rules against the settings a patch produces (recover PF ≥ trigger PF, axis min < max, a signal
 * range left on): checkSettings alone only sees the fields inside the patch.
 */
export function checkMerged(cur: CoreSettings, patch: Partial<CoreSettings>) {
  const merged: Partial<CoreSettings> = {};
  if (patch.adjust) merged.adjust = { ...cur.adjust, ...patch.adjust } as CoreSettings["adjust"];
  if (patch.axis) merged.axis = { ...cur.axis, ...patch.axis } as CoreSettings["axis"];
  if (patch.relate) merged.relate = {
    ...cur.relate,
    ...patch.relate,
    sources: { ...cur.relate.sources, ...(patch.relate.sources ?? {}) },
  } as CoreSettings["relate"];
  if (patch.signals?.ranges)
    merged.signals = {
      ranges: { ...cur.signals?.ranges, ...patch.signals.ranges },
    } as CoreSettings["signals"];
  checkSettings(merged);
}
