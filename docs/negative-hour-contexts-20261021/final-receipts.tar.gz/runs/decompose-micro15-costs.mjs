import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { readFundedSession } from '../scripts/lib/session-funded-cohort.mjs';
import { modeledUnitReturn } from '../src/core/metrics/stats.ts';
import { parseConfigId } from '../src/core/pipeline/pipeline.ts';
const stats = xs => {
  let gp=0,gl=0;
  for(const r of xs){assert.ok(Number.isFinite(r));gp+=Math.max(0,r);gl+=Math.max(0,-r);}
  return {n:xs.length,gp,gl,net:gp-gl,pf:gl>0?gp/gl:null,noLoss:gp>0&&gl===0};
};
const negative = JSON.parse(readFileSync('docs/negative-hour-contexts-20261021/negative-hour-15m-summary.json'));
const result={classification:'Fixed funded Micro15 cohort, gross-before-fixed-modeled-cost decomposition only. Primary PF remains net. No cost changes, new admission rule or venue execution claim. Counts include correlated protection sibling configs.',arms:{}};
for(const arm of ['original','expanded']){
 const {trades}=await readFundedSession(`runs/context-final-${arm}/raw.json`);
 const p=JSON.parse(readFileSync(`runs/context-final-${arm}/protocol.json`));
 const micro=trades.filter(x=>parseConfigId(x.cfg)?.protect.tag==='mc');
 const hours=new Set(negative.arms[arm].negativeHours);
 const sample={allMicro15:micro,withinOwnNegativePortfolioHours:micro.filter(x=>hours.has(Math.floor((x.exitT-1)/3600000)*3600000))};
 const out={cost:p.actualSettings.cost,samples:{}};
 for(const[name,rows]of Object.entries(sample)){
  const net=rows.map(modeledUnitReturn),gross=rows.map(x=>x.side*(x.exit-x.entry)/x.entry);
  const errors=net.map((r,i)=>Math.abs(gross[i]-p.actualSettings.cost-r));
  assert.ok(errors.every(e=>e<2e-7));
  out.samples[name]={net:stats(net),grossBeforeModeledCostDiagnostic:stats(gross),
   positiveNet:net.filter(r=>r>0).length,positiveGross:gross.filter(r=>r>0).length,
   grossWinsErasedByFixedCost:net.filter((r,i)=>r<=0&&gross[i]>0).length,
   uniqueOnsets:new Set(rows.map(x=>JSON.stringify([x.sym,x.side,x.entryT]))).size,
   configSides:new Set(rows.map(x=>JSON.stringify([x.cfg,x.side]))).size,
   maxPriceCostResidual:Math.max(0,...errors),
   averageHoldingMinutes:rows.length?rows.reduce((s,x)=>s+(x.exitT-x.entryT)/60000,0)/rows.length:null,
   maxHoldingMinutes:Math.max(0,...rows.map(x=>(x.exitT-x.entryT)/60000))};
 }
 result.arms[arm]=out;
}
writeFileSync('docs/negative-hour-contexts-20261021/micro15-cost-decomposition.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
