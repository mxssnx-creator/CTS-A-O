import { readFundedSession } from '../scripts/lib/session-funded-cohort.mjs';
import { auditSettledHours } from '../scripts/lib/postbase-hourly.mjs';
import { parseConfigId, kindOfId } from '../src/core/pipeline/pipeline.ts';
import { laneOf } from '../src/core/indications/registry.ts';
import { modeledUnitReturn } from '../src/core/metrics/stats.ts';
import { writeFileSync, readFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const H = 3600000;
const result = {
  classification: 'Post-validation diagnostics, not new source/config selection or an independent holdout. Negative hours are selected retrospectively per arm. Older v4 training Micro winners used 60m maximum holds; actual 15m Micro remains separate from other ranges. Counts across protection siblings are correlated, so unique symbol/side/onsets are disclosed.',
  returnBasis: 'Funded modeled settled net unit returns, after modeled costs once; no venue fills. GP/GL/net in summed decimal-return units. A no-loss group has null ratio, not an invented finite PF.',
  arms: {},
};
function add(map, key, x, r, h, micro, mins) {
  const id = JSON.stringify(key);
  let z = map.get(id);
  if (!z) map.set(id, z = { key, n: 0, gp: 0, gl: 0, net: 0, micro, maxHoldMinutes: mins, onsets: new Set(), hours: new Map() });
  z.n++; z.gp += Math.max(0, r); z.gl += Math.max(0, -r); z.net += r;
  z.onsets.add(JSON.stringify([x.sym, x.side, x.entryT]));
  z.hours.set(h, (z.hours.get(h) ?? 0) + r);
}
const finish = map => [...map.values()].map(z => ({
  ...z, pf: z.gl > 0 ? z.gp / z.gl : null, noLoss: z.gp > 0 && z.gl === 0,
  pfConvention: z.gl > 0 ? 'ratio' : z.gp > 0 ? 'no-loss' : 'zero-return',
  onsets: z.onsets.size, hours: [...z.hours].map(([t, net]) => ({ t, net })),
})).sort((a,b) => b.net-a.net);
for (const arm of ['original', 'expanded']) {
  const { raw, trades, funding } = await readFundedSession(`runs/context-final-${arm}/raw.json`);
  const protocol = JSON.parse(readFileSync(`runs/context-final-${arm}/protocol.json`));
  assert.equal(protocol.actualSettings.grid.micro.maxHoldMin, 15);
  const all = auditSettledHours(trades, raw.window.startT, raw.window.endT);
  const negative = new Set(all.hourly.filter(h => h.n && h.net < 0).map(h => h.t));
  const cfgs = new Map(), groups = new Map(), hourlyCfgs = new Map(), hourlyGroups = new Map();
  let microCloses = 0, negativeCloses = 0;
  const hold = new Set();
  for (const x of trades) {
    const c = parseConfigId(x.cfg); assert.ok(c);
    const tf = laneOf(c.ind).tf; assert.ok(tf);
    const mins = c.protect.hold * tf, micro = c.protect.tag === 'mc';
    if (micro) { microCloses++; hold.add(mins); assert.ok(mins <= 15); }
    const h = Math.floor((x.exitT - 1) / H) * H;
    if (!negative.has(h)) continue;
    negativeCloses++;
    const r = modeledUnitReturn(x); assert.ok(Number.isFinite(r));
    const g = [c.bot, c.ind, c.protect.tag ?? 'wide', kindOfId(x.cfg), x.side, mins];
    add(cfgs, [x.cfg, x.side], x, r, h, micro, mins);
    add(groups, g, x, r, h, micro, mins);
    add(hourlyCfgs, [h, x.cfg, x.side], x, r, h, micro, mins);
    add(hourlyGroups, [h, ...g], x, r, h, micro, mins);
  }
  const g = finish(groups), c = finish(cfgs), hg = finish(hourlyGroups), hc = finish(hourlyCfgs);
  for (const rows of [g,c,hg,hc]) assert.equal(rows.reduce((n,z) => n+z.n,0), negativeCloses);
  for (const h of all.hourly.filter(h => negative.has(h.t))) {
    const net = hg.filter(z => z.key[0] === h.t).reduce((n,z) => n+z.net,0);
    assert.ok(Math.abs(net * 100 - h.net) < 1e-8 * Math.max(1,Math.abs(h.net)));
  }
  result.arms[arm] = {
    funding, sourceSha256: protocol.source.sha256, negativeHours: [...negative], negativeCloses,
    fullHours: all.hourly, microCloses, microHoldMinutes: [...hold],
    positiveSourceGroups: g.filter(x => x.net > 0).length,
    positiveMicroSourceGroups: g.filter(x => x.micro && x.net > 0).length,
    positiveMicroConfigSides: c.filter(x => x.micro && x.net > 0).length,
    positiveMicroSourceHourGroups: hg.filter(x => x.micro && x.net > 0).length,
    positiveMicroConfigSideHours: hc.filter(x => x.micro && x.net > 0).length,
    allSourceGroups: g, allConfigSides: c, allSourceHourGroups: hg, allConfigSideHours: hc,
  };
}
const file = 'docs/negative-hour-contexts-20261021/negative-hour-15m-diagnostics.json.gz';
writeFileSync(file, gzipSync(JSON.stringify(result), { level: 9 }));
const summary = { classification: result.classification, returnBasis: result.returnBasis, detail: file.split('/').at(-1), arms: {} };
for (const [a,x] of Object.entries(result.arms)) {
  const { allSourceGroups:g, allConfigSides:c, allSourceHourGroups:hg, allConfigSideHours:hc, ...counts } = x;
  summary.arms[a] = { ...counts,
    topPositiveSourceGroups: g.filter(z => z.net > 0).slice(0,8),
    topPositiveMicroHourGroups: hg.filter(z => z.micro && z.net > 0).slice(0,8),
    topPositiveMicroConfigSideHours: hc.filter(z => z.micro && z.net > 0).slice(0,8),
  };
  console.log(a, { negativeCloses:x.negativeCloses, positiveMicroAggregate:x.positiveMicroSourceGroups, positiveMicroConfigSides:x.positiveMicroConfigSides, positiveMicroHourGroups:x.positiveMicroSourceHourGroups, positiveMicroConfigSideHours:x.positiveMicroConfigSideHours });
}
writeFileSync('docs/negative-hour-contexts-20261021/negative-hour-15m-summary.json', JSON.stringify(summary,null,2)+'\n');
