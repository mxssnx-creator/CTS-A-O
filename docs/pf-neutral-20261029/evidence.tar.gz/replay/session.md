# Simulated trading session — 8 symbols, 24 h pre-historic + 24 h run (tactics default, signals on)

Offline replay from the supplied cached candle feed (no market-data requests; original provider not recorded; simulated orders only; no exchange execution proof). Timeframe lanes 1 / 5 / 15 / 30 min set (independent + combined; traded: 1m, 5m, 5m+), strategies Normal, Trailing, Axis, DCA with Block, signals. Configured Signal gate history 24 h; available evaluated prehistory 24 h, short by 0 h; indicator-only warm-up 24 h. The 24 h general engine prehistory is a separate boundary. Balance $10.00; each order volume unit = 0.1 % of the realized account balance at entry ($0.01–$0.01 before volume factors) at 10×; 0.15 % round-trip cost on every close. Window 2026-10-08T12:00 → 2026-10-09T12:00 UTC. Engine Base 143/1398 pairs passed; Signals 1/63 representative pairs pass the diagnostic gate (excluded from Base totals) — per range, passed / evaluated pairs · applied Base PF floor and passed-pair PF scores: Wide min PF 1.25 · 8/149 · median gate PF score 1.85 · Micro min PF 1.05 · 3/519 · median gate PF score 2.30 · Minimal min PF 1.08 · 73/667 · median gate PF score 2.76 · Short min PF 1.12 · 0/48 · General min PF 1.25 · 0/47 · Long min PF 1.50 · 0/47 · Signals min PF 1.50 · 1/63 · median gate PF score 1.70; Main 77 pairs, 2468 tapes. First simulated step at 2026-10-08T12:00:00.000Z: 405 engine configs selected (Signal activation is separate). Paper selection after compute as of 2026-10-09T12:00:00.000Z: 0 engine configs + 2 Signal configs (complete paper step). Compute 9 s. The combined account PF includes both Base-qualified engine orders and separately activated Signal orders; the Base-to-execution benchmark is engine-only, and Signal PF is separate. Pre-validation candidate-pool PF is diagnostic. Causal: Base / Main / Real ranked on the history before the run.

**Simulated result (live sizing replay, position cap 0× balance per symbol × side, gross cap 0× balance (balance-volume defaults (no balance caps in the settings))):** balance $10.00 → $8.87 (-11.26 %, closed orders) · equity at end $8.86 (open at end: 3 virtual positions / 8 virtual orders (8 funded), MTM -$0.01 (exact: executed by the engine through every gate, cap and Block volume, marked to market)) · Return PF 0.27 · cash PF (base $1) 0.27 · sized $ PF diagnostic 0.30 · 52 funded positions / 3116 orders opened (49 positions / 3108 orders settled; 3 positions / 8 orders still open) · 3108 virtual closes (0 zero allocations) · WR 42.31 % · DDT (closed trades, $) 20.58 h · DDR – (net ≤ 0) · equity max drawdown $1.54 (14.79 %) · margin used max $7.69 · funded open avg 5.99 pos / 305.60 orders (peak 13 / 1210)

Qualification uses the recorded full indication's runtime gates; Tactic minimum return PF 1.1, Short minimum return PF 1.1, preserving stricter settings. No-loss qualification uses the runtime score 4.
Direct walk-forward unit returns exclude the recorded combined external execution multiplier, including any Block, Relate, coordination, range and strategy factors; ladder/tape leg semantics remain. Cash, equity and sizing retain the stored weighted results.


### Signal historic Trailing qualification

Configured Signal gate history 24 h; available evaluated prehistory 24 h, short by 0 h; indicator-only warm-up 24 h. The 24 h general engine prehistory is a separate boundary. Missing history is not a pass. Generated candidates use completed entries inside that available Signal history (configured MFE minimum 30) and are re-simulated with the lane protect, signal filter, cooldown and modeled costs. A candidate qualifies only with at least 30 closed trades, PF ≥ 1.5 and DDR ≤ 1.

| pairs | pairs with insufficient entries | trails below minimum | candidates | PF-tested | insufficient closes | PF/net rejected | DDR rejected | qualified |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 63 | 62 | 0 | 4 | 4 | 4 | 0 | 0 | 0 |
**Caps:** position cap 0× balance per symbol × side, gross cap 0× balance (balance-volume defaults (no balance caps in the settings)) — 0 orders capped to $0, 0 scaled down (open at end: 0 capped, 0 scaled) · binding: position cap 0, gross cap 0. **Without the caps:** balance $10.00 → $8.87 (-11.26 %) · Return PF 0.27 · cash PF (base $1) 0.27 · sized $ PF diagnostic 0.30 · equity at end $8.86 · equity max drawdown $1.54 (14.79 %) · margin used max $7.69.
**Virtual diagnostic:** 3108 closes · Return PF 0.27 before funding allocation; 0 zero allocations and 0 unknown allocations. Position episodes and explicitly virtual counts describe the native virtual book. Funded opening/settlement totals and headline occupancy use verified allocations; PF uses funded settled orders.

### Base gate: what each change would admit

From the same Base results — no recompute. The PF floor here changes the untagged / Wide fallback only; configured Micro, Minimal, Short, General and Long floors stay in force. "Pairs in a range" is what the tape stage builds from.

The median is the runtime's Base gate PF score. A no-loss pair uses the finite score 4; that is a qualification score, not an exact PF.

| Base gate | wide / fallback PF floor | closes | DDR | pairs at the default cell | pairs in a range | share | median PF score of the passed |
|---|---:|---:|---:|---:|---:|---:|---:|
| as run | 1.25 | 12 | 1 | 55 | 79  | 11.8 % | 1.684 |
| PF ≥ 1.00 | 1.00 | 12 | 1 | 56 | 79 (+0) | 11.8 % | 1.684 |
| PF ≥ 1.05 | 1.05 | 12 | 1 | 56 | 79 (+0) | 11.8 % | 1.684 |
| PF ≥ 1.20 | 1.20 | 12 | 1 | 56 | 79 (+0) | 11.8 % | 1.684 |
| closes ≥ 6 | 1.25 | 6 | 1 | 68 | 91 (+12) | 13.6 % | 1.774 |
| closes ≥ 20 | 1.25 | 20 | 1 | 37 | 57 (-22) | 8.5 % | 1.650 |
| closes ≥ 30 | 1.25 | 30 | 1 | 3 | 37 (-42) | 5.5 % | 1.420 |
| DDR off | 1.25 | 12 | off | 56 | 98 (+19) | 14.7 % | 1.684 |
| DDR ≤ 2 | 1.25 | 12 | 2 | 56 | 88 (+9) | 13.2 % | 1.684 |
| DDR ≤ 0.5 | 1.25 | 12 | 0.5 | 30 | 68 (-11) | 10.2 % | 2.025 |
| PF ≥ 1.00 · DDR off | 1.00 | 12 | off | 69 | 104 (+25) | 15.6 % | 1.648 |
| PF ≥ 1.00 · DDR off · closes ≥ 6 | 1.00 | 6 | off | 85 | 113 (+34) | 16.9 % | 1.658 |


### Base by range: which gate removes each pair

Each pair at the range's own cell against the range's minimum. "first" = the first gate missed (closes → net → PF → DDR); "only" = pairs that miss that one gate alone (removing it admits them).

| range | min PF | evaluated | passed | share | first: closes / net / PF / DDR | only: closes / net / PF / DDR | median PF, only DDR |
|---|---:|---:|---:|---:|---|---|---:|
| Wide | 1.25 | 149 | 8 | 5.4 % | 108 / 28 / 3 / 1 | 2 / 0 / 0 / 1 | 1.608 |
| Micro | 1.05 | 519 | 3 | 0.6 % | 414 / 95 / 0 / 7 | 5 / 0 / 0 / 7 | 1.191 |
| Minimal | 1.08 | 667 | 73 | 10.9 % | 542 / 19 / 4 / 22 | 11 / 0 / 0 / 14 | 1.299 |
| Short | 1.12 | 48 | 0 | 0.0 % | 48 / 0 / 0 / 0 | 0 / 0 / 0 / 0 | – |
| General | 1.25 | 47 | 0 | 0.0 % | 47 / 0 / 0 / 0 | 0 / 0 / 0 / 0 | – |
| Long | 1.50 | 47 | 0 | 0.0 % | 47 / 0 / 0 / 0 | 0 / 0 / 0 / 0 | – |


### After each evaluation: PF and sets validated

Base: the Base-passed pairs pooled on their gross return basis; no-loss samples show ∞ (no loss), while the runtime's finite no-loss gate score is shown separately in the run summary. Validation: the sets validated at the run start and their gross-return PF pooled on the validation window (signals: units active in the run). Orders: the run's funded settled orders and their realized PF; known zero allocations are excluded.
Validation percentages use the displayed Base-qualified config inventory, including disabled types; the separate evaluated count excludes those types. Zero or missing denominators are unavailable, not 0%. Signals require their exact-context audit; active units are not a validation percentage.
With Axis perRange off, Wide-labeled validation and orders also include independent untagged DCA/Axis configs from pairs that qualified in another range, following the recorded builder admission policy.

| range | Base pooled PF | pairs validated (%) | effective validation min PF | post-Base validation PF | sets validated (%) | settled execution PF | orders |
|---|---:|---:|---|---:|---:|---:|---:|
| Wide | 1.74 | 8 of 149 (5.37%) | 1.25 | 4.21 | 225 of 1232 (18.26%) | 0.25 | 1185 |
| Micro | 2.59 | 3 of 519 (0.58%) | 1.05 | – | 0 of 12 (0.00%) | – | 0 |
| Minimal | 2.84 | 73 of 667 (10.94%) | 1.08 | 4.39 | 180 of 316 (56.96%) | 0.31 | 1923 |
| Short | – | 0 of 48 (0.00%) | not recorded | – | – | – | 0 |
| General | – | 0 of 47 (0.00%) | not recorded | – | – | – | 0 |
| Long | – | 0 of 47 (0.00%) | not recorded | – | – | – | 0 |
| Signals | 1.70 | 1 of 63 (1.59%) | – | unavailable (use exact-context audit) | 6 units active; validation percentage unavailable | – | 0 |


### Each range at every step

Per range over the run's 24 steps: its tapes, the steps with configs validated (signals: active units) and with orders taken, and the totals.

| range | tapes | steps processed | steps with validated configs | steps with orders | validated (config × step) | candidates | orders |
|---|---:|---:|---:|---:|---:|---:|---:|
| Minimal | 438 | 24 / 24 | 16 | 12 | 1427 | 5965 | 1931 |
| Wide | 1232 | 24 / 24 | 16 | 12 | 1467 | 5139 | 1185 |
| Micro | 18 | 24 / 24 | 0 | 0 | 0 | 0 | 0 |
| exit | 24 | 24 / 24 | 0 | 0 | 0 | 0 | 0 |
| Signals | 756 | 24 / 24 | 10 | 0 | 32 | 20 | 0 |

## Hour by hour

| hour (UTC) | virtual positions / owned orders closed | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | WR | net | balance | equity (end) | equity low | equity max DD % (so far) | DD time now (h, equity) | margin max | virtual open pos / orders |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 12:00 | 2 / 128 | 59 / 69 | 1.43 | 1.88 | 46 % | $0.00 | $10.00 | $10.00 | $9.98 | 0.54 % | 0.60 | $0.96 | 8 / 206 |
| 13:00 | 4 / 441 | 403 / 38 | 8.35 | 49.19 | 91 % | $0.13 | $10.14 | $10.13 | $9.97 | 0.64 % | 0.02 | $2.54 | 12 / 149 |
| 14:00 | 1 / 287 | 250 / 37 | 28.02 | 20.32 | 87 % | $0.07 | $10.21 | $10.19 | $10.04 | 0.90 % | 0.27 | $3.36 | 11 / 392 |
| 15:00 | 14 / 462 | 358 / 104 | 0.42 | 1.62 | 77 % | $0.06 | $10.27 | $10.27 | $10.19 | 0.90 % | 0.75 | $2.22 | 2 / 2 |
| 16:00 | 8 / 61 | 52 / 9 | 22.19 | 17.69 | 85 % | $0.02 | $10.29 | $10.29 | $10.26 | 0.90 % | 1.75 | $0.31 | 7 / 13 |
| 17:00 | 12 / 19 | 19 / 0 | ∞ (no loss) | ∞ (no loss) | 100 % | $0.01 | $10.30 | $10.29 | $10.29 | 0.90 % | 2.75 | $0.08 | 7 / 7 |
| 18:00 | 0 / 270 | 8 / 262 | 0.01 | 0.00 | 3 % | -$0.14 | $10.16 | $10.08 | $9.98 | 3.93 % | 0.48 | $7.17 | 9 / 1152 |
| 19:00 | 1 / 377 | 8 / 369 | 0.01 | 0.01 | 2 % | -$0.24 | $9.92 | $9.36 | $9.25 | 10.93 % | 1.48 | $7.69 | 8 / 1013 |
| 20:00 | 0 / 434 | 3 / 431 | 0.00 | 0.00 | 1 % | -$0.59 | $9.33 | $8.93 | $8.92 | 14.12 % | 2.48 | $6.69 | 8 / 615 |
| 21:00 | 0 / 31 | 12 / 19 | 0.09 | 0.21 | 39 % | -$0.01 | $9.31 | $9.03 | $8.92 | 14.12 % | 3.48 | $3.95 | 8 / 586 |
| 22:00 | 0 / 51 | 0 / 51 | 0.00 | 0.00 | 0 % | -$0.05 | $9.27 | $8.90 | $8.88 | 14.50 % | 4.48 | $3.73 | 8 / 535 |
| 23:00 | 2 / 109 | 103 / 6 | 5.46 | 6.06 | 94 % | $0.05 | $9.31 | $9.15 | $8.86 | 14.65 % | 5.48 | $3.40 | 6 / 429 |
| 00:00 | 1 / 38 | 38 / 0 | ∞ (no loss) | ∞ (no loss) | 100 % | $0.01 | $9.32 | $9.15 | $9.11 | 14.65 % | 6.48 | $2.66 | 5 / 393 |
| 01:00 | 0 / 9 | 1 / 8 | 0.38 | 0.10 | 11 % | -$0.00 | $9.32 | $9.05 | $9.03 | 14.65 % | 7.48 | $2.48 | 7 / 392 |
| 02:00 | 1 / 156 | 1 / 155 | 0.00 | 0.00 | 1 % | -$0.13 | $9.19 | $8.97 | $8.92 | 14.65 % | 8.48 | $2.47 | 6 / 243 |
| 03:00 | 1 / 51 | 0 / 51 | 0.00 | 0.00 | 0 % | -$0.05 | $9.15 | $8.91 | $8.91 | 14.65 % | 9.48 | $1.89 | 5 / 192 |
| 04:00 | 1 / 31 | 0 / 31 | 0.00 | 0.00 | 0 % | -$0.03 | $9.11 | $8.93 | $8.88 | 14.65 % | 10.48 | $1.54 | 4 / 161 |
| 05:00 | 1 / 31 | 0 / 31 | 0.00 | 0.00 | 0 % | -$0.06 | $9.05 | $8.89 | $8.86 | 14.69 % | 11.48 | $1.30 | 3 / 130 |
| 06:00 | 0 / 0 | 0 / 0 | – | – | – | $0.00 | $9.05 | $8.87 | $8.86 | 14.69 % | 12.48 | $1.05 | 3 / 130 |
| 07:00 | 0 / 17 | 0 / 17 | 0.00 | 0.00 | 0 % | -$0.04 | $9.01 | $8.85 | $8.85 | 14.74 % | 13.48 | $1.05 | 3 / 113 |
| 08:00 | 0 / 3 | 0 / 3 | 0.00 | 0.00 | 0 % | -$0.00 | $9.01 | $8.85 | $8.85 | 14.79 % | 14.48 | $0.91 | 3 / 110 |
| 09:00 | 0 / 0 | 0 / 0 | – | – | – | $0.00 | $9.01 | $8.86 | $8.86 | 14.79 % | 15.48 | $0.89 | 3 / 110 |
| 10:00 | 0 / 78 | 0 / 78 | 0.00 | 0.00 | 0 % | -$0.11 | $8.90 | $8.87 | $8.85 | 14.79 % | 16.48 | $0.89 | 3 / 32 |
| 11:00 | 0 / 24 | 0 / 24 | 0.00 | 0.00 | 0 % | -$0.03 | $8.87 | $8.86 | $8.86 | 14.79 % | 17.48 | $0.25 | 3 / 8 |

**Last hour (11:00):** open at end: 3 virtual positions / 8 virtual orders (8 funded), MTM -$0.01 (exact: executed by the engine through every gate, cap and Block volume, marked to market); equity at the end $8.86 = balance $8.87 + MTM -$0.01.

**Hours positive:** 8 of 24 full hours · flat 2 · negative 14

*DD time now* = time since the equity (open positions marked to market) last stood at its peak, at the end of the hour; *DDT (closed trades)* in the result line is the drawdown time of the closed-trade curve. *Return PF* and *cash PF (base $1)* use the same canonical unit returns and should match; *sized $ PF diagnostic* = gross realized cash gains ÷ losses on those same orders after actual sizing; ∞ (no loss) = no losing order.

## Hour by hour per timeframe lane (orders · Return PF · net $)

| hour (UTC) | 1m | 5m | 5m+ |
|---|---:|---:|---:|
| 12:00 | 7 · 145.01 · $0.00 | 115 · 1.24 · $0.00 | 6 · 1.63 · -$0.00 |
| 13:00 | 6 · ∞ (no loss) · $0.00 | 424 · 9.49 · $0.13 | 11 · 1.00 · $0.00 |
| 14:00 | 1 · ∞ (no loss) · $0.00 | 286 · 27.93 · $0.07 | – |
| 15:00 | 12 · ∞ (no loss) · $0.00 | 443 · 0.43 · $0.06 | 7 · 0.10 · -$0.00 |
| 16:00 | 15 · 19.36 · $0.00 | 46 · 23.11 · $0.02 | – |
| 17:00 | 5 · ∞ (no loss) · $0.00 | 14 · ∞ (no loss) · $0.01 | – |
| 18:00 | 3 · 0.00 · -$0.01 | 266 · 0.01 · -$0.13 | 1 · 0.00 · -$0.00 |
| 19:00 | 3 · 0.22 · -$0.00 | 372 · 0.01 · -$0.24 | 2 · 0.00 · -$0.00 |
| 20:00 | 2 · 0.00 · -$0.00 | 420 · 0.00 · -$0.57 | 12 · 0.03 · -$0.01 |
| 21:00 | – | 26 · 0.06 · -$0.02 | 5 · ∞ (no loss) · $0.00 |
| 22:00 | – | 51 · 0.00 · -$0.05 | – |
| 23:00 | 2 · ∞ (no loss) · $0.00 | 104 · 5.29 · $0.04 | 3 · ∞ (no loss) · $0.00 |
| 00:00 | – | 34 · ∞ (no loss) · $0.01 | 4 · ∞ (no loss) · $0.00 |
| 01:00 | – | 9 · 0.38 · -$0.00 | – |
| 02:00 | 1 · 0.00 · -$0.00 | 150 · 0.00 · -$0.12 | 5 · 0.00 · -$0.00 |
| 03:00 | 1 · 0.00 · -$0.00 | 47 · 0.00 · -$0.04 | 3 · 0.00 · -$0.00 |
| 04:00 | – | 25 · 0.00 · -$0.03 | 6 · 0.00 · -$0.01 |
| 05:00 | – | 31 · 0.00 · -$0.06 | – |
| 06:00 | – | – | – |
| 07:00 | – | 17 · 0.00 · -$0.04 | – |
| 08:00 | 1 · 0.00 · -$0.00 | 2 · 0.00 · -$0.00 | – |
| 09:00 | – | – | – |
| 10:00 | – | 77 · 0.00 · -$0.11 | 1 · 0.00 · -$0.00 |
| 11:00 | – | 19 · 0.00 · -$0.02 | 5 · 0.00 · -$0.01 |

## Hour by hour per type (funded orders · Return PF · WR · net $)

The strategy columns partition funded orders; virtual closes also include zero-allocated closes. *Of which* columns are subsets of the funded orders.

| hour (UTC) | funded orders closed | virtual closes | Normal | Trailing | Trailing only | Axis | DCA | Signal · Normal | Signal · Trailing | Signal · Trailing only | of which Block-raised | of which Signals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 12:00 | 128 | 128 | 21 · 4.57 · 90 % · $0.01 | 60 · 0.97 · 27 % · -$0.00 | 6 · 0.00 · 0 % · -$0.00 | 17 · 0.00 · 0 % · -$0.00 | 24 · ∞ (no loss) · 100 % · $0.00 | – | – | – | 75 · 4.04 · 47 % · $0.00 | – |
| 13:00 | 441 | 441 | 147 · 37.22 · 99 % · $0.07 | 113 · 7.37 · 88 % · $0.05 | 10 · ∞ (no loss) · 100 % · $0.00 | 100 · 2.25 · 76 % · $0.00 | 71 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 320 · 115.67 · 97 % · $0.13 | – |
| 14:00 | 287 | 287 | 65 · ∞ (no loss) · 100 % · $0.03 | 101 · 6.99 · 67 % · $0.02 | 11 · 16.48 · 82 % · $0.00 | 20 · 2.98 · 90 % · $0.00 | 90 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 219 · 22.49 · 85 % · $0.06 | – |
| 15:00 | 462 | 462 | 156 · 2.91 · 92 % · $0.07 | 110 · 0.96 · 79 % · $0.03 | 20 · 7.62 · 90 % · $0.03 | 43 · 11.73 · 95 % · $0.00 | 133 · 0.09 · 52 % · -$0.07 | – | – | – | 383 · 0.47 · 83 % · $0.07 | – |
| 16:00 | 61 | 61 | 26 · ∞ (no loss) · 100 % · $0.01 | 25 · 4.58 · 64 % · $0.00 | – | – | 10 · ∞ (no loss) · 100 % · $0.00 | – | – | – | 61 · 22.19 · 85 % · $0.02 | – |
| 17:00 | 19 | 19 | 12 · ∞ (no loss) · 100 % · $0.01 | 3 · ∞ (no loss) · 100 % · $0.00 | – | – | 4 · ∞ (no loss) · 100 % · $0.00 | – | – | – | 19 · ∞ (no loss) · 100 % · $0.01 | – |
| 18:00 | 270 | 270 | 41 · 0.00 · 0 % · -$0.06 | 121 · 0.00 · 0 % · -$0.06 | 13 · 0.00 · 0 % · -$0.01 | 83 · 0.04 · 10 % · -$0.00 | 12 · 0.00 · 0 % · -$0.01 | – | – | – | 187 · 0.00 · 0 % · -$0.14 | – |
| 19:00 | 377 | 377 | 113 · 0.00 · 1 % · -$0.13 | 79 · 0.01 · 1 % · -$0.08 | 21 · 0.00 · 0 % · -$0.03 | 157 · 0.00 · 0 % · -$0.00 | 7 · 0.62 · 86 % · -$0.00 | – | – | – | 220 · 0.02 · 4 % · -$0.24 | – |
| 20:00 | 434 | 434 | 144 · 0.00 · 0 % · -$0.25 | 88 · 0.00 · 0 % · -$0.17 | 21 · 0.00 · 0 % · -$0.04 | 72 · 0.00 · 0 % · -$0.00 | 109 · 0.00 · 3 % · -$0.12 | – | – | – | 362 · 0.00 · 1 % · -$0.59 | – |
| 21:00 | 31 | 31 | 2 · ∞ (no loss) · 100 % · $0.00 | 7 · 2.88 · 57 % · $0.00 | 3 · ∞ (no loss) · 100 % · $0.00 | – | 19 · 0.06 · 16 % · -$0.02 | – | – | – | 31 · 0.09 · 39 % · -$0.01 | – |
| 22:00 | 51 | 51 | 25 · 0.00 · 0 % · -$0.03 | 13 · 0.00 · 0 % · -$0.01 | 2 · 0.00 · 0 % · -$0.00 | 11 · 0.00 · 0 % · -$0.00 | – | – | – | – | 40 · 0.00 · 0 % · -$0.05 | – |
| 23:00 | 109 | 109 | 31 · 3.70 · 94 % · $0.01 | 24 · 5.86 · 96 % · $0.01 | 5 · ∞ (no loss) · 100 % · $0.01 | 8 · ∞ (no loss) · 100 % · $0.00 | 41 · 4.93 · 93 % · $0.01 | – | – | – | 101 · 5.21 · 94 % · $0.05 | – |
| 00:00 | 38 | 38 | 3 · ∞ (no loss) · 100 % · $0.00 | 1 · ∞ (no loss) · 100 % · $0.00 | 1 · ∞ (no loss) · 100 % · $0.00 | – | 33 · ∞ (no loss) · 100 % · $0.01 | – | – | – | 38 · ∞ (no loss) · 100 % · $0.01 | – |
| 01:00 | 9 | 9 | 4 · 0.00 · 0 % · -$0.00 | 1 · 0.00 · 0 % · -$0.00 | – | 3 · 0.00 · 0 % · -$0.00 | 1 · ∞ (no loss) · 100 % · $0.00 | – | – | – | 6 · 0.60 · 17 % · -$0.00 | – |
| 02:00 | 156 | 156 | 35 · 0.00 · 0 % · -$0.07 | 17 · 0.00 · 0 % · -$0.03 | 4 · 0.05 · 25 % · -$0.00 | 46 · 0.00 · 0 % · -$0.00 | 54 · 0.00 · 0 % · -$0.02 | – | – | – | 110 · 0.00 · 1 % · -$0.13 | – |
| 03:00 | 51 | 51 | 20 · 0.00 · 0 % · -$0.02 | 14 · 0.00 · 0 % · -$0.02 | 5 · 0.00 · 0 % · -$0.01 | 4 · 0.00 · 0 % · -$0.00 | 8 · 0.00 · 0 % · -$0.00 | – | – | – | 47 · 0.00 · 0 % · -$0.05 | – |
| 04:00 | 31 | 31 | 17 · 0.00 · 0 % · -$0.02 | 9 · 0.00 · 0 % · -$0.01 | 1 · 0.00 · 0 % · -$0.00 | – | 4 · 0.00 · 0 % · -$0.00 | – | – | – | 31 · 0.00 · 0 % · -$0.03 | – |
| 05:00 | 31 | 31 | 17 · 0.00 · 0 % · -$0.04 | 14 · 0.00 · 0 % · -$0.03 | – | – | – | – | – | – | 31 · 0.00 · 0 % · -$0.06 | – |
| 06:00 | 0 | 0 | – | – | – | – | – | – | – | – | – | – |
| 07:00 | 17 | 17 | 7 · 0.00 · 0 % · -$0.01 | 9 · 0.00 · 0 % · -$0.02 | 1 · 0.00 · 0 % · -$0.00 | – | – | – | – | – | 17 · 0.00 · 0 % · -$0.04 | – |
| 08:00 | 3 | 3 | 2 · 0.00 · 0 % · -$0.00 | – | – | – | 1 · 0.00 · 0 % · -$0.00 | – | – | – | 3 · 0.00 · 0 % · -$0.00 | – |
| 09:00 | 0 | 0 | – | – | – | – | – | – | – | – | – | – |
| 10:00 | 78 | 78 | 32 · 0.00 · 0 % · -$0.04 | 35 · 0.00 · 0 % · -$0.05 | 11 · 0.00 · 0 % · -$0.02 | – | – | – | – | – | 78 · 0.00 · 0 % · -$0.11 | – |
| 11:00 | 24 | 24 | 10 · 0.00 · 0 % · -$0.01 | 11 · 0.00 · 0 % · -$0.01 | 3 · 0.00 · 0 % · -$0.00 | – | – | – | – | – | 24 · 0.00 · 0 % · -$0.03 | – |

## Post-Base paper Live gate

The paper entry stage independently checks each selected config's own last 25 settled post-Base execution closes since 2026-10-08T12:00:00.000Z against the stricter of its range PF floor and the Live PF floor. At the final paper step, 0 config windows had enough closes to be judged: 0 passed and 0 were paused; 0 new entry candidates were rejected by this gate. Exchange closes used: 0. Group last-N: 0.

The hourly order and PF tables above describe the causal walk-forward simulation. They are not rewritten by this later paper-stage gate; this section reports the gate's separate progress and skips.

## Stage funnel, hour by hour (post-gate virtual closes · one-unit PF)

Base (each pair at its default protect and its ranges' cells): 1335 engine pairs evaluated, 143 passed (any range); Signal pairs are measured separately. Later stages: *candidate pool* = every config of the Base-passed pairs (2468 tapes; diagnostic, before config validation), Normal / Trailing / Trailing only apart; *post-Base config passes* = 411 distinct configs passed at least one causal config-evaluation step across the window (a config can pass again in a later hour; the hourly row below counts those repeat pass instances). At run start, use the separate config-evaluation denominator/pass count and first simulated-step selection when recorded; the later paper/current selection is a separate snapshot; *post-gate virtual closes* = simulated trades that passed the causal config, coordination, caps and Block gates, before account funding/allocation. This count can include zero-allocated trades; funded settled orders and their PF are reported separately above. One-unit PF is every virtual close normalized to one unit after the 0.15 % cost. Config-evaluation history is 24 h (max of longH and preH); Base history is reported separately. Replay-only selection-window override: 24 h; it does not change normal runtime settings. The additional per-config entry last-N check is off (wf.lastN = 0); configEval still validates configs before seating. Separate post-Base paper Live-entry replay: last 25 closes per config, from 2026-10-08T12:00:00.000Z; see the Live gate section for judged and rejected counts.

| hour (UTC) | candidate pool (pre-validation) | pool Normal | pool Trailing | pool Trailing only | post-Base config-pass instances (hourly; may repeat) | post-gate virtual closes (pre-funding) | virtual Normal | virtual Trailing | virtual Trailing only | virtual Block-raised | virtual Signals |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 12:00 | 2547 · 0.18 | 196 · 0.59 | 398 · 0.44 | 344 · 0.61 | 496 · 0.25 | 128 · 1.43 | 21 · 4.57 | 60 · 0.97 | 6 · 0.00 | 75 · 4.04 | – |
| 13:00 | 4364 · 1.04 | 468 · 2.30 | 681 · 1.40 | 641 · 0.87 | 1238 · 1.42 | 441 · 8.35 | 147 · 37.22 | 113 · 7.37 | 10 · ∞ (no loss) | 320 · 115.67 | – |
| 14:00 | 2674 · 9.73 | 335 · 8.08 | 404 · 3.72 | 323 · 2.50 | 847 · 16.73 | 287 · 28.02 | 65 · ∞ (no loss) | 101 · 6.99 | 11 · 16.48 | 219 · 22.49 | – |
| 15:00 | 9573 · 0.24 | 1253 · 0.27 | 1525 · 0.27 | 1289 · 0.65 | 2049 · 0.19 | 462 · 0.42 | 156 · 2.91 | 110 · 0.96 | 20 · 7.62 | 383 · 0.47 | – |
| 16:00 | 5177 · 0.47 | 779 · 0.52 | 1096 · 0.32 | 869 · 0.16 | 1171 · 0.58 | 61 · 22.19 | 26 · ∞ (no loss) | 25 · 4.58 | – | 61 · 22.19 | – |
| 17:00 | 9312 · 0.09 | 1087 · 0.10 | 1528 · 0.15 | 1328 · 0.12 | 2027 · 0.09 | 19 · ∞ (no loss) | 12 · ∞ (no loss) | 3 · ∞ (no loss) | – | 19 · ∞ (no loss) | – |
| 18:00 | 5772 · 3.22 | 739 · 2.40 | 834 · 1.06 | 690 · 1.38 | 1733 · 3.47 | 270 · 0.01 | 41 · 0.00 | 121 · 0.00 | 13 · 0.00 | 187 · 0.00 | – |
| 19:00 | 3750 · 0.61 | 380 · 0.26 | 432 · 0.22 | 344 · 0.04 | 1010 · 0.34 | 377 · 0.01 | 113 · 0.00 | 79 · 0.01 | 21 · 0.00 | 220 · 0.02 | – |
| 20:00 | 4939 · 0.05 | 502 · 0.04 | 509 · 0.07 | 437 · 0.04 | 1504 · 0.04 | 434 · 0.00 | 144 · 0.00 | 88 · 0.00 | 21 · 0.00 | 362 · 0.00 | – |
| 21:00 | 1979 · 1.87 | 232 · 3.84 | 410 · 2.01 | 343 · 2.91 | 560 · 1.64 | 31 · 0.09 | 2 · ∞ (no loss) | 7 · 2.88 | 3 · ∞ (no loss) | 31 · 0.09 | – |
| 22:00 | 1357 · 0.26 | 131 · 0.42 | 130 · 0.10 | 160 · 0.39 | 375 · 0.30 | 51 · 0.00 | 25 · 0.00 | 13 · 0.00 | 2 · 0.00 | 40 · 0.00 | – |
| 23:00 | 2274 · 0.92 | 288 · 0.71 | 214 · 0.74 | 284 · 3.84 | 679 · 0.70 | 109 · 5.46 | 31 · 3.70 | 24 · 5.86 | 5 · ∞ (no loss) | 101 · 5.21 | – |
| 00:00 | 1172 · 1.52 | 154 · 0.95 | 185 · 1.04 | 162 · 0.78 | 331 · 1.47 | 38 · ∞ (no loss) | 3 · ∞ (no loss) | 1 · ∞ (no loss) | 1 · ∞ (no loss) | 38 · ∞ (no loss) | – |
| 01:00 | 2469 · 0.32 | 234 · 0.22 | 302 · 0.18 | 300 · 0.23 | 550 · 0.19 | 9 · 0.38 | 4 · 0.00 | 1 · 0.00 | – | 6 · 0.60 | – |
| 02:00 | 3046 · 0.23 | 333 · 0.46 | 458 · 0.43 | 419 · 0.51 | 907 · 0.29 | 156 · 0.00 | 35 · 0.00 | 17 · 0.00 | 4 · 0.05 | 110 · 0.00 | – |
| 03:00 | 1607 · 0.10 | 170 · 0.15 | 198 · 0.22 | 199 · 0.23 | 394 · 0.09 | 51 · 0.00 | 20 · 0.00 | 14 · 0.00 | 5 · 0.00 | 47 · 0.00 | – |
| 04:00 | 2422 · 0.15 | 357 · 0.31 | 316 · 0.17 | 270 · 0.19 | 659 · 0.19 | 31 · 0.00 | 17 · 0.00 | 9 · 0.00 | 1 · 0.00 | 31 · 0.00 | – |
| 05:00 | 1313 · 0.19 | 188 · 0.30 | 220 · 0.20 | 182 · 0.13 | 300 · 0.20 | 31 · 0.00 | 17 · 0.00 | 14 · 0.00 | – | 31 · 0.00 | – |
| 06:00 | 1645 · 0.37 | 275 · 0.83 | 324 · 0.38 | 227 · 0.06 | 503 · 0.62 | – | – | – | – | – | – |
| 07:00 | 3779 · 0.30 | 532 · 0.38 | 693 · 0.40 | 664 · 0.44 | 880 · 0.34 | 17 · 0.00 | 7 · 0.00 | 9 · 0.00 | 1 · 0.00 | 17 · 0.00 | – |
| 08:00 | 2210 · 6.31 | 287 · 2.59 | 367 · 1.31 | 292 · 1.53 | 595 · 12.41 | 3 · 0.00 | 2 · 0.00 | – | – | 3 · 0.00 | – |
| 09:00 | 1284 · 2.33 | 141 · 1.60 | 226 · 1.00 | 184 · 0.84 | 362 · 5.46 | – | – | – | – | – | – |
| 10:00 | 1367 · 0.46 | 159 · 0.36 | 212 · 0.14 | 219 · 0.20 | 478 · 0.29 | 78 · 0.00 | 32 · 0.00 | 35 · 0.00 | 11 · 0.00 | 78 · 0.00 | – |
| 11:00 | 2686 · 1.78 | 305 · 1.60 | 370 · 0.84 | 333 · 1.06 | 744 · 2.49 | 24 · 0.00 | 10 · 0.00 | 11 · 0.00 | 3 · 0.00 | 24 · 0.00 | – |
| **total** | **78718 · 0.42** | **9525 · 0.44** | **12032 · 0.35** | **10503 · 0.43** | **20392 · 0.41** | **3108 · 0.27** | **930 · 0.32** | **855 · 0.27** | **138 · 0.42** | **2403 · 0.25** | **–** |

## Strategies

The type rows are one partition of the book (they add up to *total*); *of which* rows are subsets. DDT on each group's own $ curve, to the run end.

| strategy | orders | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | net | WR | DDT (h) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Normal | 930 | 446 / 484 | 0.32 | 0.32 | 0.32 | -$0.48 | 47.96 % | 18.17 |
| Trailing | 855 | 319 / 536 | 0.27 | 0.27 | 0.27 | -$0.38 | 37.31 % | 20.58 |
| Trailing only | 138 | 47 / 91 | 0.42 | 0.42 | 0.43 | -$0.06 | 34.06 % | 20.50 |
| Axis | 564 | 151 / 413 | 0.22 | 0.22 | 0.22 | -$0.01 | 26.77 % | 20.58 |
| DCA | 621 | 352 / 269 | 0.25 | 0.25 | 0.23 | -$0.19 | 56.68 % | 20.92 |
| Signal · Normal | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Signal · Trailing | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Signal · Trailing only | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| total | 3108 | 1315 / 1793 | 0.27 | 0.27 | 0.30 | -$1.13 | 42.31 % | 20.58 |
| of which Block-raised | 2403 | 1078 / 1325 | 0.25 | 0.25 | 0.29 | -$1.12 | 44.86 % | 20.58 |
| of which Signals | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| of which Engine (no signals) | 3108 | 1315 / 1793 | 0.27 | 0.27 | 0.30 | -$1.13 | 42.31 % | 20.58 |

## Timeframe lanes

| lane | orders | Return PF | cash PF (base $1) | sized $ PF diagnostic | net |
|---|---:|---:|---:|---:|---:|
| 1m | 59 | 0.55 | 0.55 | 0.62 | -$0.01 |
| 5m | 2978 | 0.27 | 0.27 | 0.30 | -$1.09 |
| 5m+ | 71 | 0.21 | 0.21 | 0.21 | -$0.03 |

A 24 h window is a short sample: it shows the engine processing correctly and its current edge, not a durable result.

## Ranges in the executed book

Signals are a range of their own (signal configs carry no range tag); every enabled range listed.

| range | orders | wins / losses | Return PF | cash PF (base $1) | sized $ PF diagnostic | net | WR | DDT (h) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Micro | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Minimal | 1923 | 812 / 1111 | 0.31 | 0.31 | 0.31 | -$0.93 | 42.23 % | 18.17 |
| Short | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| General | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Long | 0 | 0 / 0 | – | – | – | $0.00 | – | – |
| Wide | 1185 | 503 / 682 | 0.25 | 0.25 | 0.23 | -$0.20 | 42.45 % | 20.92 |
| Signals | 0 | 0 / 0 | – | – | – | $0.00 | – | – |

### Why candidates did not execute, per range

Every entry candidate of a seated config (and of an active signal) the run skipped, by the first gate it failed.

| range | skipped | reasons (count) |
|---|---:|---|
| Minimal | 4034 | directionValidation 3364 · configValidation 361 · symPf 309 |
| Wide | 3954 | directionValidation 3029 · configValidation 538 · symPf 387 |
| Signals | 20 | sig:confirm 20 |

## Base said, the book did — the same ranges on the same basis

The combined account result includes every funded engine and Signal order. For the Base-to-execution benchmark, engine range rows contain only funded orders from Base-qualified pairs whose configs passed post-Base validation; Signals are separately activated, qualified and reported. All PF gates use net returns. Base lists a median gate score across passed pairs on its Base sample; a no-loss Base sample has an exact pooled PF of ∞ and a separate finite gate score. The run PF is on the actual executed order cohort. These samples and reducers differ, so
their difference alone does not establish edge loss or a sizing effect. Cash PF is a separate diagnostic on
the same closed orders as the book's return PF; unequal notionals can change cash PF without changing return PF.

| range | Base passed (median gate score, validation sample) | simulated return PF (run closes) | cash PF (base $1) | sized $ PF diagnostic (same run closes) | orders |
|---|---:|---:|---:|---:|---:|
| Micro | 2.30 | – | – | – | 0 |
| Minimal | 2.76 | 0.31 | 0.31 | 0.31 | 1923 |
| Short | – | – | – | – | 0 |
| General | – | – | – | – | 0 |
| Long | – | – | – | – | 0 |
| Wide | 1.85 | 0.25 | 0.25 | 0.23 | 1185 |
| Signals | 1.70 | – | – | – | 0 |

## Seated configs over the run window, by range and type

Engine configs that passed the seat evaluation (configEval) at the run start (405 of 1276 evaluated, 1712 engine tapes) and the signal configs' entries made while their unit (pair × symbol × direction) was active at the entry's step (0 units active at the run start, 6 over the run, 6 of 756 signal configs with such an entry), each on its own closes inside the run (entries ≥ start, exits ≤ end). Net in % of one unit; PF unit basis.

| range | type | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | normal | 82 | 0 (0 %) | 4703 | 53 % | 0.41 | -2323.06 |
| Minimal | trailing | 81 | 0 (0 %) | 4662 | 43 % | 0.28 | -2276.37 |
| Minimal | trailing-only | 17 | 0 (0 %) | 598 | 38 % | 0.37 | -300.60 |
| Wide | axis | 137 | 0 (0 %) | 6012 | 29 % | 0.34 | -3103.65 |
| Wide | dca | 88 | 2 (2 %) | 4398 | 69 % | 0.49 | -5038.13 |
| Signals | normal | 2 | 1 (50 %) | 9 | 67 % | 0.97 | -0.07 |
| Signals | trailing | 2 | 2 (100 %) | 5 | 80 % | 1.14 | 0.15 |
| Signals | trailing-only | 2 | 1 (50 %) | 5 | 20 % | 0.97 | -0.11 |

| range | indication kind | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | active | 130 | 0 (0 %) | 8007 | 49 % | 0.37 | -3804.27 |
| Minimal | inverse | 47 | 0 (0 %) | 1761 | 41 % | 0.29 | -1023.18 |
| Minimal | micro | 3 | 0 (0 %) | 195 | 47 % | 0.47 | -72.58 |
| Wide | active | 190 | 1 (1 %) | 8872 | 47 % | 0.44 | -6874.13 |
| Wide | inverse | 31 | 1 (3 %) | 1260 | 46 % | 0.41 | -1141.01 |
| Wide | micro | 4 | 0 (0 %) | 278 | 33 % | 0.43 | -126.63 |
| Signals | signal:macd-cross | 6 | 4 (67 %) | 19 | 58 % | 1.00 | -0.04 |

### Seat evaluation (configEval) at the run start, per range (configs failing at each gate, first gate missed)

Each engine config on its own closes at the run start (configEval: the gates the seat selection applies — not the Base stage, which ranks bot × indication pairs): over the selection window (24 h) ≥ max(3, 12) closes, positive net, PF ≥ its full indication's range minimum (stage 1.25; general 1.25, long 1.5, micro 1.05, minimal 1.08, short 1.12; full indication-aware Tactic floor 1.1, Short floor 1.1, retaining stricter settings; mixed indication groups can have different minima), drawdown time ≤ min(11.67 h, 35 h × span ÷ 72 h), span = the tape's own history inside the 24 h window (ddtLimitH: a 1m tape with 72 h of history → 35 h; a full window → 11.67 h), drawdown ratio ≤ 1, last 12 closes at the same PF / DDT, range cells' last 75 at PF ≥ 1.35, positive lower-confidence bound, green hours ≥ 50 %. Real entries then check the last 0 closes again. Signal configs are not evaluated here: they are seated by their own signal activation. PF medians: the configEval window PF of every evaluated config / of the passed ones (unit basis; a config with no loss uses the runtime's no-loss gate score, not an exact finite ratio).

| range | configs | evaluated | passed | median PF score (evaluated) | median PF score (passed) | DDT limit h (min–max) | closes | net | pf | pre | lcb | lastN | rangeGate | context | ddt | ddr | green | stable | type off | pair not Base-passed | note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Micro | 18 | 12 | 0 | 0.78 | – | 11.67–11.67 (median 11.67) | 12 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 6 |  |
| Minimal | 438 | 316 | 180 | 3.99 | 5.60 | 11.67–11.67 (median 11.67) | 71 | 25 | 4 | 0 | 20 | 15 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 122 |  |
| Short | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| General | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| Long | 0 | 0 | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 0 configs — no config sets built for this range |
| Wide | 1232 | 924 | 225 | 1.54 | 3.45 | 11.67–11.67 (median 11.67) | 425 | 165 | 40 | 0 | 56 | 12 | 0 | 0 | 0 | 1 | 0 | 0 | 308 | 0 |  |
| Exit | 24 | 24 | 0 | 1.17 | – | 11.67–11.67 (median 11.67) | 0 | 9 | 7 | 0 | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | range off: tapes from an earlier setting |
| Signals | 756 | – | 0 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 756 signal tapes, 0 units (pair × symbol × direction) active at the run start, 6 over the run; 6 configs entered while their unit was active — seated per unit and step, not configEval |

## Diagnostic: every config over the run window, by range and type (context: seated or not)

Each config computed independently (unit size, 0.15 % cost per close), on the book's rule (entries ≥ start, exits ≤ end); net in % of one unit summed over the closes. This all-candidate table is diagnostic only: it is not the PF benchmark and does not qualify or dilute the post-Base execution cohort.

| range | type | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Micro | normal | 6 | 0 (0 %) | 194 | 50 % | 0.32 | -37.72 |
| Micro | trailing | 6 | 0 (0 %) | 199 | 29 % | 0.22 | -36.48 |
| Micro | trailing-only | 6 | 0 (0 %) | 199 | 28 % | 0.30 | -32.64 |
| Minimal | normal | 146 | 2 (1 %) | 7750 | 54 % | 0.43 | -3593.59 |
| Minimal | trailing | 146 | 2 (1 %) | 8712 | 44 % | 0.31 | -3663.25 |
| Minimal | trailing-only | 146 | 2 (1 %) | 8679 | 42 % | 0.42 | -3150.79 |
| Wide | axis | 616 | 11 (2 %) | 20478 | 29 % | 0.33 | -10342.80 |
| Wide | dca | 308 | 14 (5 %) | 13722 | 62 % | 0.46 | -20589.36 |
| Wide | dca-active | 308 | 1 (0 %) | 10692 | 27 % | 0.43 | -3563.21 |
| Signals | normal | 189 | 7 (4 %) | 1581 | 48 % | 0.55 | -347.59 |
| Signals | trailing | 378 | 14 (4 %) | 3121 | 44 % | 0.50 | -706.90 |
| Signals | trailing-only | 189 | 10 (5 %) | 1625 | 40 % | 0.58 | -262.09 |
| Exit | exit | 24 | 0 (0 %) | 1766 | 28 % | 0.38 | -527.04 |

## Range cells by indication kind (seated configs; signal configs by source)

| range | kind | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | active | 130 | 0 (0 %) | 8007 | 49 % | 0.37 | -3804.27 |
| Minimal | inverse | 47 | 0 (0 %) | 1761 | 41 % | 0.29 | -1023.18 |
| Minimal | micro | 3 | 0 (0 %) | 195 | 47 % | 0.47 | -72.58 |
| Wide | active | 190 | 1 (1 %) | 8872 | 47 % | 0.44 | -6874.13 |
| Wide | inverse | 31 | 1 (3 %) | 1260 | 46 % | 0.41 | -1141.01 |
| Wide | micro | 4 | 0 (0 %) | 278 | 33 % | 0.43 | -126.63 |
| Signals | signal:macd-cross | 6 | 4 (67 %) | 19 | 58 % | 1.00 | -0.04 |

## Causal last-50 gate on the seated configs: their last 50 closes before the run cleared the PF, then inside the run

| range | min PF | configs | positive | closes | WR | PF unit | net % |
|---|---|---:|---:|---:|---:|---:|---:|
| Minimal | 1.1 | 25 | 0 (0 %) | 2052 | 50 % | 0.41 | -769.48 |
| Minimal | 1.25 | 22 | 0 (0 %) | 1759 | 50 % | 0.39 | -691.93 |
| Minimal | 1.35 | 22 | 0 (0 %) | 1759 | 50 % | 0.39 | -691.93 |
| Minimal | 1.5 | 18 | 0 (0 %) | 1422 | 50 % | 0.37 | -567.30 |
| Minimal | 1.75 | 18 | 0 (0 %) | 1422 | 50 % | 0.37 | -567.30 |
| Minimal | 2 | 14 | 0 (0 %) | 1083 | 49 % | 0.35 | -445.27 |
| Wide | 1.1 | 13 | 0 (0 %) | 972 | 75 % | 0.51 | -885.66 |
| Wide | 1.25 | 13 | 0 (0 %) | 972 | 75 % | 0.51 | -885.66 |
| Wide | 1.35 | 12 | 0 (0 %) | 885 | 75 % | 0.52 | -784.65 |
| Wide | 1.5 | 11 | 0 (0 %) | 804 | 75 % | 0.52 | -709.19 |
| Wide | 1.75 | 11 | 0 (0 %) | 804 | 75 % | 0.52 | -709.19 |
| Wide | 2 | 6 | 0 (0 %) | 413 | 77 % | 0.61 | -265.89 |

## Indications per range (seated configs of the indication together; positive net first, then by net)

| range | bot | indication | configs | positive | closes | WR | PF unit | net % | best config (closes · PF unit · net %) |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| Minimal | follow | inverse-market-residual-10@m5 | 2 | 0 (0 %) | 70 | 69 % | 0.85 | -5.70 | tp0.8 sl2.4 tr0 h192 mn (29 · 0.98 · -0.35) |
| Minimal | follow | mc-rsi7-25@m5 | 1 | 0 (0 %) | 39 | 51 % | 0.31 | -19.71 | tp0.8 sl2.4 tr0.4 h192 mn (39 · 0.31 · -19.71) |
| Minimal | follow | mc-rsi9-30@m5 | 1 | 0 (0 %) | 48 | 46 % | 0.34 | -21.00 | tp0.8 sl2.4 tr0.4 h192 mn (48 · 0.34 · -21.00) |
| Minimal | follow | mc-rsi3-25@m5 | 1 | 0 (0 %) | 80 | 71 % | 0.64 | -21.21 | tp0.8 sl2.4 tr0 h192 mn (80 · 0.64 · -21.21) |
| Minimal | follow | mc-macdh@m5 | 1 | 0 (0 %) | 76 | 67 % | 0.52 | -30.17 | tp0.8 sl2.4 tr0 h192 mn (76 · 0.52 · -30.17) |
| Minimal | follow | inverse-acceleration-10@m1 | 1 | 0 (0 %) | 84 | 48 % | 0.35 | -33.08 | tp0.8 sl2.4 tr0.4 h960 mn (84 · 0.35 · -33.08) |
| Minimal | follow | inverse-known-trend-ema@m5c | 4 | 0 (0 %) | 90 | 36 % | 0.36 | -34.29 | tp0.8 sl1.2 tr0.4 h192 mn (24 · 0.52 · -5.45) |
| Minimal | follow | mc-rsit5-30@m5 | 1 | 0 (0 %) | 59 | 59 % | 0.38 | -37.34 | tp0.8 sl2.4 tr0 h192 mn (59 · 0.38 · -37.34) |
| Minimal | follow | inverse-consensus-10@m1 | 1 | 0 (0 %) | 109 | 52 % | 0.39 | -39.13 | tp0.8 sl2.4 tr0.4 h960 mn (109 · 0.39 · -39.13) |
| Minimal | follow | mc-vwapd-2@m5 | 4 | 0 (0 %) | 101 | 50 % | 0.34 | -47.79 | tp0.8 sl2.4 tr0 h192 mn (22 · 0.58 · -6.99) |
| Minimal | follow | mc-rsi5-30@m5 | 3 | 0 (0 %) | 207 | 59 % | 0.59 | -48.09 | tp0.8 sl1.2 tr0 h192 mn (76 · 0.74 · -10.60) |
| Minimal | follow | mc-rsi4-30@m5 | 2 | 0 (0 %) | 151 | 62 % | 0.49 | -52.44 | tp0.8 sl2.4 tr0 h192 mn (67 · 0.56 · -23.26) |
| Minimal | follow | inverse-zscore-10@m5 | 4 | 0 (0 %) | 112 | 43 % | 0.38 | -54.31 | tp0 sl1.2 tr0.4 h192 mn to tm3 (31 · 0.52 · -10.43) |
| Minimal | follow | inverse-mc-zscore-10@m5 | 4 | 0 (0 %) | 112 | 43 % | 0.38 | -54.31 | tp0 sl1.2 tr0.4 h192 mn to tm3 (31 · 0.52 · -10.43) |
| Minimal | follow | mc-rsi3-20@m5 | 3 | 0 (0 %) | 244 | 61 % | 0.62 | -54.44 | tp0.8 sl1.2 tr0 h192 mn (90 · 0.76 · -11.50) |
| Minimal | follow | mc-rsit3-30@m5 | 2 | 0 (0 %) | 176 | 59 % | 0.46 | -69.57 | tp0.8 sl2.4 tr0 h192 mn (84 · 0.52 · -33.48) |
| Minimal | follow | inverse-known-trend-ema@m5 | 6 | 0 (0 %) | 214 | 45 % | 0.47 | -70.26 | tp0 sl1.2 tr0.4 h192 mn to tm3 (40 · 0.68 · -6.14) |
| Minimal | follow | mc-rsi5-25@m5 | 4 | 0 (0 %) | 270 | 50 % | 0.52 | -71.81 | tp0.8 sl1.2 tr0.4 h192 mn (80 · 0.48 · -16.49) |
| Minimal | follow | micro-5x15-drawdown-turn-fast@m5 | 3 | 0 (0 %) | 195 | 47 % | 0.47 | -72.58 | tp0 sl2.4 tr0.4 h192 mn to tm3 (62 · 0.66 · -16.07) |
| Minimal | follow | mc-rsi7-30@m5 | 4 | 0 (0 %) | 230 | 47 % | 0.45 | -74.00 | tp0.8 sl1.2 tr0 h192 mn (62 · 0.58 · -15.70) |
| Minimal | follow | mc-rsit9-30@m5 | 3 | 0 (0 %) | 150 | 43 % | 0.31 | -76.00 | tp0.8 sl1.2 tr0.4 h192 mn (56 · 0.31 · -23.36) |
| Minimal | follow | mc-rsi3-15@m5 | 4 | 0 (0 %) | 261 | 51 % | 0.50 | -76.60 | tp0.8 sl1.2 tr0 h192 mn (68 · 0.61 · -15.80) |
| Minimal | follow | mc-rsi4-25@m5 | 4 | 0 (0 %) | 310 | 54 % | 0.54 | -77.00 | tp0.8 sl2.4 tr0 h192 mn (57 · 0.61 · -16.41) |
| Minimal | follow | mc-rsi2-10@m5 | 3 | 0 (0 %) | 281 | 54 % | 0.50 | -77.31 | tp0.8 sl1.2 tr0 h192 mn (95 · 0.69 · -16.25) |
| Minimal | follow | mc-rsi2-30@m5c | 3 | 0 (0 %) | 178 | 53 % | 0.42 | -80.13 | tp0.8 sl1.2 tr0 h192 mn (66 · 0.61 · -15.10) |
| Minimal | follow | mc-streak-4@m5 | 4 | 0 (0 %) | 191 | 48 % | 0.38 | -82.63 | tp0.8 sl1.2 tr0.4 h192 mn (51 · 0.36 · -15.77) |
| Minimal | follow | mc-rsi2-5@m5 | 4 | 0 (0 %) | 250 | 48 % | 0.46 | -83.86 | tp0.8 sl1.2 tr0.4 h192 mn (70 · 0.43 · -18.06) |
| Minimal | follow | mc-rsit2-15@m5 | 2 | 0 (0 %) | 168 | 55 % | 0.36 | -89.08 | tp0.8 sl2.4 tr0 h192 mn (79 · 0.42 · -43.43) |
| Minimal | follow | mc-rsi4-20@m5 | 4 | 0 (0 %) | 255 | 45 % | 0.43 | -90.94 | tp0.8 sl1.2 tr0 h192 mn (65 · 0.53 · -19.75) |
| Minimal | follow | mc-rsi4-15@m5 | 4 | 0 (0 %) | 171 | 44 % | 0.30 | -92.37 | tp0.8 sl1.2 tr0.4 h192 mn (47 · 0.35 · -14.74) |
| Minimal | follow | mc-bbx-20@m5 | 4 | 0 (0 %) | 182 | 46 % | 0.32 | -98.26 | tp0.8 sl1.2 tr0 h192 mn (48 · 0.44 · -18.80) |
| Minimal | follow | mc-rsi3-10@m5 | 4 | 0 (0 %) | 188 | 39 % | 0.28 | -99.23 | tp0.8 sl1.2 tr0.4 h192 mn (54 · 0.27 · -18.31) |
| Minimal | follow | inverse-failed-break-10@m5 | 5 | 0 (0 %) | 202 | 40 % | 0.35 | -99.51 | tp0 sl2.4 tr0.4 h192 mn to tm3 (36 · 0.50 · -15.21) |
| Minimal | follow | mc-rsit7-25@m5 | 3 | 0 (0 %) | 146 | 33 % | 0.19 | -99.90 | tp0.8 sl1.2 tr0.4 h192 mn (54 · 0.17 · -30.78) |
| Minimal | follow | mc-exh-12-3@m5 | 3 | 0 (0 %) | 127 | 43 % | 0.23 | -101.13 | tp0.8 sl1.2 tr0 h192 mn (51 · 0.34 · -26.85) |
| Minimal | follow | mc-rsit4-30@m5 | 3 | 0 (0 %) | 239 | 53 % | 0.42 | -101.27 | tp0.8 sl1.2 tr0 h192 mn (92 · 0.50 · -30.20) |
| Minimal | follow | mc-rsit4-25@m5 | 3 | 0 (0 %) | 213 | 50 % | 0.35 | -113.65 | tp0.8 sl1.2 tr0 h192 mn (82 · 0.46 · -30.70) |
| Minimal | follow | mc-rsit2-10@m5 | 3 | 0 (0 %) | 246 | 53 % | 0.40 | -114.36 | tp0.8 sl1.2 tr0 h192 mn (97 · 0.49 · -32.95) |
| Minimal | follow | mc-rsit3-20@m5 | 3 | 0 (0 %) | 237 | 52 % | 0.38 | -114.38 | tp0.8 sl1.2 tr0 h192 mn (93 · 0.51 · -29.55) |
| Minimal | follow | mc-rsit3-15@m5 | 3 | 0 (0 %) | 197 | 49 % | 0.32 | -118.74 | tp0.8 sl1.2 tr0 h192 mn (78 · 0.41 · -33.30) |
| Minimal | follow | mc-rsit3-25@m5 | 3 | 0 (0 %) | 271 | 53 % | 0.42 | -119.13 | tp0.8 sl1.2 tr0 h192 mn (105 · 0.53 · -31.75) |
| Minimal | follow | inverse-turn-trend-ema@m5 | 4 | 0 (0 %) | 193 | 41 % | 0.28 | -128.96 | tp0 sl2.4 tr0.4 h192 mn to tm3 (46 · 0.33 · -27.62) |
| Minimal | follow | mc-rsit7-30@m5 | 4 | 0 (0 %) | 233 | 44 % | 0.31 | -131.19 | tp0.8 sl1.2 tr0.4 h192 mn (68 · 0.29 · -29.15) |
| Minimal | follow | mc-mturn-5@m5 | 4 | 0 (0 %) | 168 | 38 % | 0.20 | -137.25 | tp0.8 sl1.2 tr0.4 h192 mn (47 · 0.22 · -27.37) |
| Minimal | follow | mc-rsit4-15@m5 | 4 | 0 (0 %) | 183 | 39 % | 0.22 | -137.83 | tp0.8 sl1.2 tr0.4 h192 mn (55 · 0.20 · -29.76) |
| Minimal | follow | mc-rsit5-20@m5 | 4 | 0 (0 %) | 195 | 38 % | 0.23 | -138.36 | tp0.8 sl1.2 tr0 h192 mn (56 · 0.31 · -31.60) |
| Minimal | follow | inverse-vwap-deviation-10@m5 | 4 | 0 (0 %) | 188 | 41 % | 0.25 | -142.01 | tp0 sl2.4 tr0.4 h192 mn to tm3 (45 · 0.30 · -30.40) |
| Minimal | follow | mc-mturn-10@m5 | 4 | 0 (0 %) | 287 | 49 % | 0.34 | -148.96 | tp0.8 sl1.2 tr0 h192 mn (79 · 0.45 · -30.65) |
| Minimal | follow | mc-rsit3-10@m5 | 4 | 0 (0 %) | 200 | 38 % | 0.20 | -155.62 | tp0.8 sl1.2 tr0.4 h192 mn (58 · 0.17 · -35.51) |
| Minimal | follow | mc-rsit5-25@m5 | 4 | 0 (0 %) | 275 | 43 % | 0.29 | -158.13 | tp0.8 sl1.2 tr0.4 h192 mn (82 · 0.26 · -35.43) |
| Minimal | follow | inverse-acceleration-10@m5 | 6 | 0 (0 %) | 149 | 21 % | 0.07 | -167.18 | tp0 sl1.2 tr0.4 h192 mn to tm3 (29 · 0.06 · -24.58) |
| Minimal | follow | mc-rsit4-20@m5 | 4 | 0 (0 %) | 271 | 44 % | 0.27 | -170.02 | tp0.8 sl1.2 tr0 h192 mn (77 · 0.38 · -35.95) |
| Minimal | follow | mc-rsit2-5@m5 | 4 | 0 (0 %) | 253 | 42 % | 0.24 | -173.37 | tp0.8 sl1.2 tr0 h192 mn (69 · 0.33 · -37.15) |
| Minimal | follow | inverse-consensus-10@m5 | 6 | 0 (0 %) | 238 | 34 % | 0.18 | -194.46 | tp0 sl1.2 tr0.4 h192 mn to tm3 (47 · 0.23 · -26.83) |
| Wide | follow | inverse-market-residual-10@m5 | 1 | 1 (100 %) | 35 | 86 % | 1.05 | 1.23 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (35 · 1.05 · 1.23) |
| Wide | follow | act-burst-2.5@x4@m1 | 2 | 0 (0 %) | 62 | 90 % | 0.89 | -4.20 | tp0.55 sl0.59 tr0 h480 dc2s1q0g0.5r2.5m2 dca (31 · 0.95 · -0.96) |
| Wide | follow | inverse-known-trend-ema@m1c | 1 | 0 (0 %) | 48 | 79 % | 0.81 | -13.14 | tp0.81 sl0.84 tr0 h480 dc2s1q0g0.5r2.5m2 dca (48 · 0.81 · -13.14) |
| Wide | follow | mc-rsi5-20@m5 | 2 | 1 (50 %) | 88 | 80 % | 0.89 | -13.82 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (43 · 1.04 · 2.42) |
| Wide | follow | mc-rsi7-25@m5 | 2 | 0 (0 %) | 74 | 76 % | 0.84 | -19.81 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (34 · 0.96 · -2.17) |
| Wide | follow | inverse-acceleration-10@m5 | 1 | 0 (0 %) | 23 | 65 % | 0.49 | -26.38 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (23 · 0.49 · -26.38) |
| Wide | follow | mc-rsit5-20@m5 | 1 | 0 (0 %) | 42 | 74 % | 0.51 | -38.45 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (42 · 0.51 · -38.45) |
| Wide | follow | inverse-zscore-10@m5 | 1 | 0 (0 %) | 26 | 62 % | 0.24 | -48.86 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (26 · 0.24 · -48.86) |
| Wide | follow | inverse-mc-zscore-10@m5 | 1 | 0 (0 %) | 26 | 62 % | 0.24 | -48.86 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (26 · 0.24 · -48.86) |
| Wide | follow | mc-rsi4-15@m5 | 2 | 0 (0 %) | 75 | 73 % | 0.63 | -51.45 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (37 · 0.73 · -18.98) |
| Wide | follow | mc-rsit7-25@m5 | 1 | 0 (0 %) | 38 | 68 % | 0.37 | -54.27 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (38 · 0.37 · -54.27) |
| Wide | follow | inverse-known-trend-ema@m5c | 2 | 0 (0 %) | 43 | 67 % | 0.36 | -56.21 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (21 · 0.39 · -26.87) |
| Wide | follow | mc-exh-12-3@m5 | 5 | 0 (0 %) | 124 | 27 % | 0.36 | -67.16 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (25 · 0.44 · -9.80) |
| Wide | follow | mc-rsi9-30@m5 | 2 | 0 (0 %) | 82 | 72 % | 0.57 | -71.19 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (44 · 0.66 · -23.82) |
| Wide | follow | mc-rsi3-10@m5 | 2 | 0 (0 %) | 78 | 68 % | 0.50 | -86.50 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (38 · 0.56 · -38.91) |
| Wide | follow | mc-rsit9-30@m5 | 3 | 0 (0 %) | 147 | 39 % | 0.44 | -86.89 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (54 · 0.39 · -23.48) |
| Wide | follow | inverse-consensus-10@m1 | 1 | 0 (0 %) | 87 | 71 % | 0.48 | -101.02 | tp1.01 sl1.03 tr0 h480 dc2s1q0g0.5r2.5m2 dca (87 · 0.48 · -101.02) |
| Wide | follow | mc-vwapd-2@m5 | 6 | 0 (0 %) | 142 | 42 % | 0.41 | -101.74 | tp0.64 sl0.68 tr0 h96 ax-fib2 axis (22 · 0.17 · -13.35) |
| Wide | follow | mc-rsi4-25@m5 | 4 | 0 (0 %) | 210 | 61 % | 0.60 | -107.44 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (38 · 0.38 · -16.16) |
| Wide | follow | mc-rsit3-15@m5 | 4 | 0 (0 %) | 174 | 28 % | 0.27 | -108.03 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (47 · 0.31 · -22.05) |
| Wide | follow | mc-bbx-20@m5 | 2 | 0 (0 %) | 84 | 68 % | 0.41 | -108.24 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (43 · 0.40 · -52.48) |
| Wide | follow | mc-rsi5-30@m5 | 3 | 0 (0 %) | 180 | 73 % | 0.67 | -112.99 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (71 · 0.75 · -21.84) |
| Wide | follow | mc-rsi3-15@m5 | 4 | 0 (0 %) | 194 | 62 % | 0.53 | -114.25 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (40 · 0.50 · -10.79) |
| Wide | follow | mc-rsi2-25@m5c | 2 | 0 (0 %) | 97 | 70 % | 0.44 | -122.21 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (50 · 0.46 · -51.98) |
| Wide | follow | mc-rsi2-30@m5c | 2 | 0 (0 %) | 113 | 73 % | 0.47 | -123.93 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (57 · 0.49 · -53.39) |
| Wide | follow | mc-streak-4@m5 | 2 | 0 (0 %) | 89 | 70 % | 0.38 | -124.20 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (44 · 0.41 · -61.21) |
| Wide | follow | mc-rsi3-25@m5 | 6 | 0 (0 %) | 269 | 31 % | 0.39 | -125.12 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (43 · 0.48 · -14.39) |
| Wide | follow | micro-5-drawdown-turn-fast@m5 | 4 | 0 (0 %) | 278 | 33 % | 0.43 | -126.63 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (79 · 0.45 · -29.51) |
| Wide | follow | mc-rsit4-15@m5 | 5 | 0 (0 %) | 165 | 33 % | 0.31 | -133.73 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (34 · 0.17 · -21.73) |
| Wide | follow | mc-rsit3-30@m5 | 3 | 0 (0 %) | 211 | 47 % | 0.46 | -136.50 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (62 · 0.41 · -26.29) |
| Wide | follow | mc-rsi2-5@m5 | 2 | 0 (0 %) | 112 | 70 % | 0.41 | -147.64 | tp0.82 sl0.85 tr0 h96 dc2s1q0g0.5r2.5m2 dca (55 · 0.44 · -73.19) |
| Wide | follow | mc-rsit3-10@m5 | 2 | 0 (0 %) | 90 | 64 % | 0.38 | -148.96 | tp0.64 sl0.68 tr0 h96 dc2s1q0g0.5r2.5m2 dca (46 · 0.37 · -69.89) |
| Wide | follow | mc-rsit3-25@m5 | 3 | 0 (0 %) | 210 | 45 % | 0.43 | -149.18 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (64 · 0.38 · -28.29) |
| Wide | follow | mc-rsit4-30@m5 | 3 | 0 (0 %) | 198 | 43 % | 0.39 | -151.22 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (64 · 0.39 · -28.27) |
| Wide | follow | mc-macdh@m5 | 8 | 0 (0 %) | 262 | 26 % | 0.24 | -154.95 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (32 · 0.25 · -17.77) |
| Wide | follow | inverse-consensus-10@m5 | 6 | 0 (0 %) | 193 | 39 % | 0.36 | -170.32 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (36 · 0.29 · -18.61) |
| Wide | follow | mc-rsi4-20@m5 | 6 | 0 (0 %) | 292 | 51 % | 0.46 | -174.07 | tp0.64 sl0.68 tr0 h96 ax-fib2 axis (45 · 0.44 · -12.35) |
| Wide | follow | mc-rsi3-20@m5 | 4 | 0 (0 %) | 237 | 63 % | 0.47 | -174.77 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (40 · 0.49 · -12.71) |
| Wide | follow | mc-rsit3-20@m5 | 5 | 0 (0 %) | 280 | 41 % | 0.44 | -178.14 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (59 · 0.44 · -21.85) |
| Wide | follow | mc-rsit2-10@m5 | 5 | 0 (0 %) | 277 | 39 % | 0.52 | -180.02 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (61 · 0.50 · -19.73) |
| Wide | follow | mc-rsit4-25@m5 | 5 | 0 (0 %) | 269 | 38 % | 0.40 | -192.97 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (58 · 0.38 · -25.08) |
| Wide | follow | inverse-rsi2-turn-10@m5 | 5 | 0 (0 %) | 262 | 35 % | 0.45 | -194.74 | tp0.64 sl0.68 tr0 h96 ax-linear2 axis (42 · 0.36 · -25.40) |
| Wide | follow | mc-rsi7-30@m5 | 11 | 0 (0 %) | 444 | 45 % | 0.59 | -196.62 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (38 · 0.44 · -13.44) |
| Wide | follow | mc-rsi4-30@m5 | 4 | 0 (0 %) | 228 | 63 % | 0.46 | -203.36 | tp0.64 sl0.68 tr0 h96 ax-linear2 axis (36 · 0.48 · -17.31) |
| Wide | follow | inverse-turn-trend-ema@m5 | 6 | 0 (0 %) | 299 | 44 % | 0.40 | -216.31 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (61 · 0.41 · -23.27) |
| Wide | follow | mc-rsi5-25@m5 | 11 | 0 (0 %) | 482 | 47 % | 0.58 | -219.27 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (40 · 0.44 · -14.02) |
| Wide | follow | mc-rsit2-5@m5 | 4 | 0 (0 %) | 187 | 42 % | 0.42 | -233.31 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (38 · 0.18 · -23.90) |
| Wide | follow | mc-rsit7-30@m5 | 6 | 0 (0 %) | 310 | 40 % | 0.38 | -246.24 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (61 · 0.36 · -28.35) |
| Wide | follow | inverse-vwap-deviation-10@m5 | 6 | 0 (0 %) | 218 | 33 % | 0.34 | -266.42 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (37 · 0.15 · -25.23) |
| Wide | follow | mc-rsit5-30@m5 | 6 | 0 (0 %) | 340 | 43 % | 0.37 | -286.61 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (62 · 0.38 · -27.43) |
| Wide | follow | mc-mturn-10@m5 | 9 | 0 (0 %) | 432 | 31 % | 0.37 | -307.82 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (49 · 0.41 · -19.98) |
| Wide | follow | mc-rsit2-15@m5 | 6 | 0 (0 %) | 392 | 44 % | 0.48 | -308.38 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (69 · 0.39 · -28.73) |
| Wide | follow | mc-rsit5-25@m5 | 7 | 0 (0 %) | 371 | 42 % | 0.35 | -417.27 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (58 · 0.36 · -27.06) |
| Wide | follow | mc-rsit4-20@m5 | 7 | 0 (0 %) | 349 | 42 % | 0.34 | -432.70 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (49 · 0.29 · -24.93) |
| Wide | follow | mc-mturn-5@m5 | 11 | 0 (0 %) | 372 | 29 % | 0.26 | -458.52 | tp0.64 sl0.68 tr0 h96 ax-geo2 axis (34 · 0.17 · -21.48) |
| Signals | follow | sig-macd-cross-s@m5 | 3 | 2 (67 %) | 6 | 33 % | 1.00 | -0.01 | – |
| Signals | follow | sig-macd-cross-s@m1 | 3 | 2 (67 %) | 13 | 69 % | 0.99 | -0.03 | tp0.52 sl0.56 tr0 h2880 tm3 (6 · 1.04 · 0.06) |

## Best range cells by net (seated configs, ≥ 10 closes, all pairs together)

| range | TP | SL | trail | configs | positive | closes | WR | PF unit | net % |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| Wide | tp 0.550% | sl 1.07× | tr off | 1 | 0 (0 %) | 31 | 90 % | 0.95 | -0.96 |
| Wide | tp 0.500% | sl 1.08× | tr off | 1 | 0 (0 %) | 31 | 90 % | 0.83 | -3.24 |
| Wide | tp 0.810% | sl 1.04× | tr off | 1 | 0 (0 %) | 48 | 79 % | 0.81 | -13.14 |
| Wide | tp 1.010% | sl 1.02× | tr off | 1 | 0 (0 %) | 87 | 71 % | 0.48 | -101.02 |
| Minimal | tp 0.000% | sl Infinity× | tr Infinity× | 17 | 0 (0 %) | 598 | 38 % | 0.37 | -300.60 |
| Minimal | tp 0.800% | sl 1.50× | tr 0.50× | 31 | 0 (0 %) | 1825 | 38 % | 0.29 | -734.02 |
| Minimal | tp 0.800% | sl 1.50× | tr off | 40 | 0 (0 %) | 2545 | 47 % | 0.43 | -1021.75 |
| Wide | tp 1.570% | sl 1.01× | tr off | 12 | 0 (0 %) | 602 | 51 % | 0.50 | -1066.03 |
| Minimal | tp 0.800% | sl 3.00× | tr off | 42 | 0 (0 %) | 2158 | 60 % | 0.39 | -1301.31 |
| Minimal | tp 0.800% | sl 3.00× | tr 0.50× | 50 | 0 (0 %) | 2837 | 45 % | 0.27 | -1542.35 |
| Wide | tp 0.820% | sl 1.04× | tr off | 36 | 1 (3 %) | 1894 | 69 % | 0.48 | -2211.95 |
| Wide | tp 0.640% | sl 1.06× | tr off | 173 | 1 (1 %) | 7717 | 39 % | 0.40 | -4745.44 |

## Worst range cells by net (seated configs, the rows not in the best table)

| range | TP | SL | trail | configs | positive | closes | WR | PF unit | net % |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| – | | | | | | | | | |

## Config sets: completeness (the Base gate decides which pairs and targets build)

Every indication × range × strategy type: the grid's cells (target × stop × trail × hold), built (simulated), kept before the pre-run range gate, rejected by that gate, eligible after it, dropped for too few closes (the range gate's last N can never be met), and not built by reason (baseRange: the pair did not pass Base in that range; baseTarget: the target did not pass Base; duplicate: two grid cells map onto one config on a slow lane).

| range | type | indications (with sets) | grid cells | built | kept before gate | gate rejected | eligible | too few closes | not built |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| Micro | normal | 58 (3) | 122 | 6 | 6 | 0 | 6 | 0 | baseRange 116 |
| Micro | trailing | 58 (3) | 122 | 6 | 6 | 0 | 6 | 0 | baseRange 116 |
| Micro | trailing-only | 58 (3) | 122 | 6 | 6 | 0 | 6 | 0 | baseRange 116 |
| Minimal | normal | 69 (66) | 154 | 146 | 146 | 0 | 146 | 0 | baseRange 8 |
| Minimal | trailing | 69 (66) | 154 | 146 | 146 | 0 | 146 | 0 | baseRange 8 |
| Minimal | trailing-only | 69 (66) | 154 | 146 | 146 | 0 | 146 | 0 | baseRange 8 |
| Wide | axis | 69 (69) | 616 | 616 | 616 | 0 | 616 | 0 | – |
| Wide | dca | 69 (69) | 308 | 308 | 308 | 0 | 308 | 0 | – |
| Wide | dca-active | 69 (69) | 308 | 308 | 308 | 0 | 308 | 0 | – |
| Wide | exit | 7 (7) | 24 | 24 | 24 | 0 | 24 | 0 | – |

Engine indications Base evaluated that built no set: 110 (act-chop@x4, bb-walk@x4, break-atr-2@x4, break-mc-rel-don-5-dd24-guarded, break-vol, break-vol-2@x4, cci-14-200@x4, cci-40-200@x4, cfl-trend-50, dir-emax-5-13, dir-vwap-240, ema-50-100, ema-stoch, htfpb-4, htfpb-8, ichi-cloud-20, inverse-impulse-10, inverse-micro-1-drawdown-turn-fast, inverse-regression-10, inverse-wick-10, low-range-1-edge-turn-standalone, mc-act-idio-2, mc-act-idio-3, mc-act-mkt-18, mc-act-mkt-25, mc-bbrk-20, mc-bbx-25, mc-brk-10, mc-brk-20, mc-burst-2, mc-burst-3, mc-climax-3, mc-climax-4, mc-exh-12-5, mc-exh-4-3, mc-exh-4-5, mc-fbo-96, mc-ibrk, mc-irsi2-10, mc-ivwapd-2, …).

## Heatmaps: target × stop per range (PF unit, closes; every type and trail together)

### Micro — every config computed

| stop ÷ target | tp 0.35 % |
|---|---:|
| 1× | 0.23 (201) |
| 5× | 0.31 (192) |

### Micro — configs that passed their evaluation

| stop ÷ target | tp 0.35 % |
|---|---:|
| 1× | – |
| 5× | – |

### Micro — orders executed

| stop ÷ target | tp 0.35 % |
|---|---:|
| 1× | – |
| 5× | – |

### Minimal — every config computed

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 0.41 (9290) |
| 3× | 0.35 (7172) |

### Minimal — configs that passed their evaluation

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 0.38 (4370) |
| 3× | 0.33 (4995) |

### Minimal — orders executed

| stop ÷ target | tp 0.8 % |
|---|---:|
| 1.5× | 0.36 (741) |
| 3× | 0.27 (1044) |

### Wide — every config computed

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.64 % | tp 0.81 % | tp 0.82 % | tp 1.01 % | tp 1.57 % | tp 2.07 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1× | – | – | – | – | – | – | – | 0.42 (4901) |
| 1.01× | – | – | – | – | – | – | 0.45 (5449) | – |
| 1.02× | – | – | – | – | – | 0.50 (377) | – | – |
| 1.04× | – | – | – | 0.49 (406) | 0.48 (6030) | – | – | – |
| 1.06× | – | – | 0.37 (26526) | – | – | – | – | – |
| 1.07× | – | 0.39 (440) | – | – | – | – | – | – |
| 1.08× | 0.40 (763) | – | – | – | – | – | – | – |

### Wide — configs that passed their evaluation

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.64 % | tp 0.81 % | tp 0.82 % | tp 1.01 % | tp 1.57 % | tp 2.07 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1× | – | – | – | – | – | – | – | – |
| 1.01× | – | – | – | – | – | – | 0.50 (602) | – |
| 1.02× | – | – | – | – | – | 0.48 (87) | – | – |
| 1.04× | – | – | – | 0.81 (48) | 0.48 (1894) | – | – | – |
| 1.06× | – | – | 0.40 (7717) | – | – | – | – | – |
| 1.07× | – | 0.95 (31) | – | – | – | – | – | – |
| 1.08× | 0.83 (31) | – | – | – | – | – | – | – |

### Wide — orders executed

| stop ÷ target | tp 0.5 % | tp 0.55 % | tp 0.64 % | tp 0.81 % | tp 0.82 % | tp 1.01 % | tp 1.57 % | tp 2.07 % |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1× | – | – | – | – | – | – | – | – |
| 1.01× | – | – | – | – | – | – | 0.29 (37) | – |
| 1.02× | – | – | – | – | – | 0.28 (11) | – | – |
| 1.04× | – | – | – | – | 0.25 (253) | – | – | – |
| 1.06× | – | – | 0.23 (863) | – | – | – | – | – |
| 1.07× | – | ∞ (3) | – | – | – | – | – | – |
| 1.08× | 0.41 (18) | – | – | – | – | – | – | – |

### Exit — every config computed

| stop ÷ target | tp 0.91 % | tp 1.03 % | tp 1.08 % | tp 1.14 % | tp 1.18 % | tp 1.23 % | tp 1.33 % |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0.38× | – | – | – | – | – | – | 0.37 (178) |
| 0.52× | – | – | – | – | – | 0.27 (178) | – |
| 0.57× | – | – | 0.49 (152) | – | – | – | – |
| 0.59× | – | – | – | 0.22 (182) | – | – | – |
| 0.6× | – | – | – | – | 0.31 (182) | – | – |
| 0.68× | – | 0.43 (128) | – | – | – | – | – |
| 1× | 0.45 (129) | 0.49 (110) | 0.50 (117) | 0.31 (71) | 0.38 (71) | 0.36 (126) | 0.42 (51) |

### Exit — configs that passed their evaluation

| stop ÷ target | tp 0.91 % | tp 1.03 % | tp 1.08 % | tp 1.14 % | tp 1.18 % | tp 1.23 % | tp 1.33 % |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0.38× | – | – | – | – | – | – | – |
| 0.52× | – | – | – | – | – | – | – |
| 0.57× | – | – | – | – | – | – | – |
| 0.59× | – | – | – | – | – | – | – |
| 0.6× | – | – | – | – | – | – | – |
| 0.68× | – | – | – | – | – | – | – |
| 1× | – | – | – | – | – | – | – |

### Exit — orders executed

| stop ÷ target | tp 0.91 % | tp 1.03 % | tp 1.08 % | tp 1.14 % | tp 1.18 % | tp 1.23 % | tp 1.33 % |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0.38× | – | – | – | – | – | – | – |
| 0.52× | – | – | – | – | – | – | – |
| 0.57× | – | – | – | – | – | – | – |
| 0.59× | – | – | – | – | – | – | – |
| 0.6× | – | – | – | – | – | – | – |
| 0.68× | – | – | – | – | – | – | – |
| 1× | – | – | – | – | – | – | – |
